package top.niunaijun.blackboxa.util;

interface IShizukuFileService {
    String[] getApkPaths(String packageName);
    boolean copyFile(String sourcePath, String targetPath);
}
