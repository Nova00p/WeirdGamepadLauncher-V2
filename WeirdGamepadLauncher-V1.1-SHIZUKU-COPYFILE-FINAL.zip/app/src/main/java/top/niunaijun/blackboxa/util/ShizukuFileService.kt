package top.niunaijun.blackboxa.util

import java.io.File

/**
 * Runs inside a Shizuku UserService (shell/root identity).
 * Only performs the privileged APK path lookup/open operations needed by staging.
 */
class ShizukuFileService : IShizukuFileService.Stub() {
    override fun getApkPaths(packageName: String): Array<String> {
        require(packageName.matches(Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+$")))
        val process = ProcessBuilder("pm", "path", packageName)
            .redirectErrorStream(false)
            .start()
        val output = process.inputStream.bufferedReader().use { it.readText() }
        val error = process.errorStream.bufferedReader().use { it.readText() }
        val code = process.waitFor()
        if (code != 0) throw IllegalStateException("pm path failed ($code): ${error.trim()}")
        return output.lineSequence()
            .map { it.trim() }
            .filter { it.startsWith("package:/") }
            .map { it.removePrefix("package:") }
            .distinct()
            .toList()
            .toTypedArray()
    }

    override fun copyFile(sourcePath: String, targetPath: String): Boolean {
        require(sourcePath.startsWith("/data/app/") || sourcePath.startsWith("/product/app/") || sourcePath.startsWith("/system/app/") || sourcePath.startsWith("/system_ext/app/")) { "Unexpected APK path" }
        val source = File(sourcePath)
        val target = File(targetPath)
        target.parentFile?.mkdirs()
        source.inputStream().use { input ->
            target.outputStream().use { output ->
                input.copyTo(output, 1024 * 1024)
            }
        }
        return target.exists() && target.length() > 0L
    }
}
