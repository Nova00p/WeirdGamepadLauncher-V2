package top.niunaijun.blackboxa.util

import android.content.Context
import android.util.Log
import rikka.shizuku.Shizuku
import java.io.File

/**
 * Extracts an installed package's APK files using Shizuku's shell identity.
 * The copies are placed in this app's private cache so BlackBox can read them.
 */
object ShizukuApkStager {
    const val REQUEST_CODE = 4101
    private const val TAG = "ShizukuApkStager"
    private val PACKAGE_REGEX = Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+$")

    fun stagePackage(context: Context, packageName: String): Result<File> {
        return try {
            require(PACKAGE_REGEX.matches(packageName)) { "Invalid package name" }
            if (Shizuku.isPreV11() || Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                error("Shizuku permission is not granted")
            }

            val paths = queryApkPaths(packageName)
            if (paths.isEmpty()) error("No APK paths returned by package manager")

            val root = File(context.cacheDir, "staged_apps/$packageName").apply {
                if (exists()) deleteRecursively()
                mkdirs()
            }

            var baseFile: File? = null
            paths.forEachIndexed { index, sourcePath ->
                val name = if (sourcePath.endsWith("/base.apk")) "base.apk" else "split_${index}_${File(sourcePath).name}"
                val target = File(root, name)
                copyPrivilegedFile(sourcePath, target)
                if (name == "base.apk") baseFile = target
            }

            require(baseFile?.exists() == true && baseFile!!.length() > 0) { "Base APK could not be staged" }
            Log.d(TAG, "Staged ${paths.size} APK(s) for $packageName at ${root.absolutePath}")
            Result.success(baseFile!!)
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to stage $packageName", t)
            Result.failure(t)
        }
    }

    private fun queryApkPaths(packageName: String): List<String> {
        val process = Shizuku.newProcess(arrayOf("sh", "-c", "pm path $packageName"), null, null)
        val output = process.inputStream.bufferedReader().use { it.readText() }
        val error = process.errorStream.bufferedReader().use { it.readText() }
        val code = process.waitFor()
        if (code != 0) error("pm path failed ($code): ${error.trim()}")
        return output.lineSequence()
            .map { it.trim() }
            .filter { it.startsWith("package:") }
            .map { it.removePrefix("package:") }
            .filter { it.startsWith("/") }
            .distinct()
            .toList()
    }

    private fun copyPrivilegedFile(sourcePath: String, target: File) {
        val safePath = sourcePath.replace("'", "'\\''")
        val process = Shizuku.newProcess(arrayOf("sh", "-c", "cat '$safePath'"), null, null)
        process.inputStream.use { input ->
            target.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
        }
        val error = process.errorStream.bufferedReader().use { it.readText() }
        val code = process.waitFor()
        if (code != 0) {
            target.delete()
            error("APK copy failed ($code): ${error.trim()}")
        }
    }
}
