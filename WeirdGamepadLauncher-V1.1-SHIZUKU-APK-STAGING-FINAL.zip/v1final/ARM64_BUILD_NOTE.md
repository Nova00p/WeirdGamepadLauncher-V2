# ARM64 build note

This package is configured to build only the `arm64-v8a` APK.

This changes the APK architecture selection; it does not by itself solve Kotlin compilation errors or guarantee that every dependency is compatible with Android 15/16.
