# WeirdGamepadLauncher V1 build notes

This package is based on NewBlackbox and is intended as the V1 virtual-app foundation.

Included build fixes:
- Removed the unavailable StateView dependency.
- Added the BlackReflection core and compiler dependencies required by the Blackbox core.
- Removed Aliyun Maven mirrors.
- Added JitPack and SciJava repositories.
- Added a workflow that can extract a ZIP and locate the Android project automatically.
- Application ID: `com.weirdgamepad.launcher.v1`

V1 scope:
- Virtual-app foundation from NewBlackbox.
- App installation/listing/launching provided by the imported NewBlackbox UI/core.
- No USB rumble, accelerometer learning, or controller interception.

This package still requires a GitHub Actions build and real-device test. A successful Gradle build does not guarantee that every guest APK works on every Android version.
