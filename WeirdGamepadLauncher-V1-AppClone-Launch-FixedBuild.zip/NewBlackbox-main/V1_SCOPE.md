# WeirdGamepadLauncher V1 scope

This V1 package is the NewBlackbox-based virtual-app manager base, with a corrected build workflow and no controller, sensor, or USB-rumble features added.

V1 target workflow:

1. Open the launcher.
2. Add/import a compatible APK.
3. Install it in the virtual environment.
4. Clone the virtual app where supported by the underlying engine.
5. List the virtual app and clone separately.
6. Launch the selected virtual app.
7. Remove/refresh virtual apps.

The underlying virtualization engine may not support every APK. Compatibility must be tested on the target phone. This package is not a guarantee that every game, Google Play service, DRM system, or native library will work.

The GitHub Actions workflow accepts either an already-extracted project or a ZIP archive. Upload the ZIP itself if desired; do not upload the ZIP inside another ZIP.
