# V1 final scope

This V1 is the BlackBox/NewBlackbox virtual-app foundation with a corrected host app picker.

Flow: launcher -> + -> host installed launchable apps -> select app -> clone into BlackBox -> cloned app appears -> launch clone.

The Add/Choose screen no longer opens Android's document picker. The Telegram menu item is removed. Controller/USB/haptic features are intentionally deferred to V2.

The build is configured for arm64-v8a.
