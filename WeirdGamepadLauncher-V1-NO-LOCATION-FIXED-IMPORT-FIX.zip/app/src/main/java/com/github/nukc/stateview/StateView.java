package com.github.nukc.stateview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

/** Minimal local compatibility view used by the NewBlackbox UI. */
public class StateView extends FrameLayout {
    public StateView(Context context) { super(context); }
    public StateView(Context context, AttributeSet attrs) { super(context, attrs); }
    public StateView(Context context, AttributeSet attrs, int defStyleAttr) { super(context, attrs, defStyleAttr); }
    public void showLoading() { setVisibility(View.VISIBLE); }
    public void showEmpty() { setVisibility(View.VISIBLE); }
    public void showContent() { setVisibility(View.VISIBLE); }
}
