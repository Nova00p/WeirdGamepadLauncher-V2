# WeirdGamepadLauncher V2 — Phase 1 Foundation

This repository is the initial Phase 1 foundation for WeirdGamepadLauncher V2.

## Current scope

- New project identity: `WeirdGamepadLauncher-V2`
- New application ID: `com.weirdgamepad.launcher.v2`
- New launcher icon based on the supplied WeirdGamepad mascot
- New project branding in the app label
- NewBlackBox source retained as the virtualization foundation
- No rumble interception yet
- No USB ownership code yet
- No final launcher UI yet

## Phase 1 goal

Prepare and verify the real virtualization foundation, then add the first controlled flow for installing and launching Minecraft as a guest application.

## Important

The current source is a foundation import. Android 15 device testing is required before claiming that guest launching works on the target device.
