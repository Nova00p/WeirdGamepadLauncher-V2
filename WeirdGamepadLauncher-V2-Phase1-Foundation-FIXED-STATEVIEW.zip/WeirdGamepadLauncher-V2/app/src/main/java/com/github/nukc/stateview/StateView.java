package com.github.nukc.stateview;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

/**
 * Small local compatibility replacement for the unavailable StateView library.
 * The current project only needs the state-changing methods, so these methods
 * intentionally keep the container available without requiring an external
 * Maven dependency.
 */
public class StateView extends FrameLayout {
    public StateView(Context context) {
        super(context);
    }

    public StateView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public StateView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void showLoading() {
        setVisibility(VISIBLE);
    }

    public void showContent() {
        setVisibility(VISIBLE);
    }

    public void showEmpty() {
        setVisibility(VISIBLE);
    }

    public void showError() {
        setVisibility(VISIBLE);
    }
}
