package com.github.nukc.stateview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

/** Minimal local replacement for the unavailable StateView dependency. */
public class StateView extends FrameLayout {
    private View contentView;
    public StateView(Context context) { super(context); }
    public StateView(Context context, AttributeSet attrs) { super(context, attrs); }
    public StateView(Context context, AttributeSet attrs, int defStyleAttr) { super(context, attrs, defStyleAttr); }
    public void showLoading() { setVisibility(VISIBLE); }
    public void showContent() { setVisibility(VISIBLE); }
    public void showEmpty() { setVisibility(VISIBLE); }
    public void showError() { setVisibility(VISIBLE); }
    public void setContentView(View view) { contentView = view; }
    public View getContentView() { return contentView; }
}
