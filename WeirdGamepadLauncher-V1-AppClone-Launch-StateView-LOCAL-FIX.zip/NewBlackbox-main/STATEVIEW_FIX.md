The unavailable com.github.nukc.stateview:kotlin:2.2.0 dependency was removed.
A minimal local compatibility implementation is included at:
app/src/main/java/com/github/nukc/stateview/StateView.java
