# V1.1 cloning fixes

This build changes the clone flow in three places:

- ListActivity now preserves and returns the actual BlackBox profile/user ID.
- MainActivity targets the fragment by its real user ID instead of assuming ViewPager position == user ID.
- ShizukuApkStager verifies every staged APK is non-empty and always selects a usable base APK.
- AppsRepository validates the staged APK before installing and verifies that BlackBox reports the same package installed for the selected user.

The BlackBox AAR's public API exposes `installPackageAsUser(File, int)` and does not expose a split-APK/session installer, so this patch keeps the existing BlackBox installation API rather than inventing one.
