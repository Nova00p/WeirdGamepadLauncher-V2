# Android 14 AttributionSource crash fix

The crash log showed:

`Calling uid: 11312 doesn't match source uid: 10001`

The failure occurs while `ContentProviderDelegate.init()` calls the Settings provider through
`SystemProviderStub`.

The bundled Bcore `SystemProviderStub` was passing `BlackBoxCore.getHostUid()` when fixing
the Android `AttributionSource`. In the virtual app process, the Binder caller is the
virtual process UID, so the patched class uses `android.os.Process.myUid()` instead.

Changed class:

`top/niunaijun/blackbox/fake/service/context/providers/SystemProviderStub`

Changed operation:

`BlackBoxCore.getHostUid()` -> `Process.myUid()`

This patch is applied directly to `app/libs/Bcore-release.aar` in this project ZIP.
No cloning/UI code was changed by this patch.
