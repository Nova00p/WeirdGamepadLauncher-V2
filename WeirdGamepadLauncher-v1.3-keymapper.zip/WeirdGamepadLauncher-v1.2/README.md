# WeirdGamepad Launcher v1.3 Mapper

Java/XML Android launcher with an in-game floating controller mapper.

## Mapping workflow

1. Enable WeirdGamepad Launcher in Android Accessibility settings.
2. Launch a game from the launcher.
3. The small `WG MAPPER` floating window appears.
4. Tap the menu (`☰`).
5. Tap `ADD BUTTON`.
6. Press the physical gamepad button you want to assign.
7. The assigned marker appears in the centre of the game.
8. Drag that marker over the game's real touch button.
9. Lock the mapper and save the profile.
10. Pressing that gamepad button later dispatches a tap at the saved position.

Profiles are stored per game package name.

## Mouse zone

`MOUSE ZONE` creates a configurable area. In `MOUSE MODE`, the D-pad moves a virtual cursor inside the zone and A clicks. A true global analog right-stick mouse requires a privileged input-capture/injection layer; the normal Accessibility API does not expose every controller motion event globally.

## Controller inputs

The tester supports standard gamepad keys and displays analog trigger/stick axes. The mapper captures controller key events through the AccessibilityService key filter.

## Build

The project uses Android Gradle Plugin 8.9.1, compileSdk 36, targetSdk 35, Java 17 and Gradle 8.11.1.
