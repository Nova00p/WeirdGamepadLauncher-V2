package com.nova00p.weirdgamepadlauncher;

import android.graphics.RectF;
import java.util.LinkedHashMap;
import java.util.Map;

public final class MappingProfile {
    public static final String TYPE_TAP = "tap";
    public static final String TYPE_MOUSE_ZONE = "mouse_zone";

    public final Map<Integer, Control> controls = new LinkedHashMap<>();
    public RectF mouseZone = new RectF(0.10f, 0.20f, 0.90f, 0.80f);
    public boolean hasMouseZone = false;
    public float mouseSensitivity = 1.0f;

    public static final class Control {
        public int keyCode;
        public String label;
        public String type = TYPE_TAP;
        public float x;
        public float y;
        public float size = 0.075f;

        public Control(int keyCode, String label, float x, float y) {
            this.keyCode = keyCode;
            this.label = label;
            this.x = x;
            this.y = y;
        }
    }
}
