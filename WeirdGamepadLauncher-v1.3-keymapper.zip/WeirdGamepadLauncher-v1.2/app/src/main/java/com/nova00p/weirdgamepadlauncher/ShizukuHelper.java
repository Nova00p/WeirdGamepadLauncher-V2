package com.nova00p.weirdgamepadlauncher;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import rikka.shizuku.Shizuku;

public final class ShizukuHelper {
    private static final int REQUEST_CODE = 101;

    private ShizukuHelper() {}

    public static boolean isRunning() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean hasPermission() {
        if (!isRunning()) return false;
        try {
            return Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    public static void requestPermission() {
        if (!isRunning()) return;
        try {
            if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(REQUEST_CODE);
            }
        } catch (Throwable ignored) {}
    }

    public static void openShizuku(Context context) {
        try {
            Intent i = context.getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
            if (i != null) context.startActivity(i);
            else context.startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://shizuku.rikka.app/download/")));
        } catch (Throwable ignored) {}
    }
}
