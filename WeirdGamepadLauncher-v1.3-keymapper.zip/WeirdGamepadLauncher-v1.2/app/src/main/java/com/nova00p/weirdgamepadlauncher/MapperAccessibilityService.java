package com.nova00p.weirdgamepadlauncher;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/**
 * The actual in-game mapper overlay.
 *
 * Flow:
 * 1. Launch a game from the launcher.
 * 2. A small floating WG button appears.
 * 3. Tap it -> mapper menu opens.
 * 4. Tap ADD BUTTON -> the service waits for the next gamepad button.
 * 5. The assigned button appears at the centre of the screen.
 * 6. EDIT mode lets the user drag it over the game's real touch control.
 * 7. LOCK makes the mapping non-touchable and game input is translated to taps.
 */
public class MapperAccessibilityService extends AccessibilityService {
    private static MapperAccessibilityService instance;

    private WindowManager wm;
    private FrameLayout touchLayer;
    private LinearLayout floatingPanel;
    private LinearLayout menuPanel;
    private TextView title;
    private TextView status;

    private String targetPackage;
    private MappingProfile profile;

    private boolean menuOpen = false;
    private boolean editMode = false;
    private boolean hideTouchButtons = false;
    private boolean waitingForAssignment = false;
    private boolean mouseMode = false;

    private float mouseX = 0.5f;
    private float mouseY = 0.5f;

    public static boolean isRunning() {
        return instance != null;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    public static void startOverlay(android.content.Context context, String packageName) {
        if (instance != null) {
            instance.showOverlay(packageName);
        }
    }

    private void showOverlay(String packageName) {
        targetPackage = packageName;
        profile = ProfileStore.loadProfile(this, packageName);
        createWindowsIfNeeded();
        menuOpen = false;
        waitingForAssignment = false;
        editMode = false;
        renderTouchLayer();
        updatePanel();
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 22
                ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void createWindowsIfNeeded() {
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (touchLayer == null) createTouchLayer();
        if (floatingPanel == null) createFloatingPanel();
    }

    private void createTouchLayer() {
        touchLayer = new FrameLayout(this);
        touchLayer.setBackgroundColor(Color.TRANSPARENT);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;

        try {
            wm.addView(touchLayer, lp);
        } catch (Throwable t) {
            touchLayer = null;
        }
    }

    private void createFloatingPanel() {
        floatingPanel = new LinearLayout(this);
        floatingPanel.setOrientation(LinearLayout.VERTICAL);
        floatingPanel.setPadding(dp(6), dp(6), dp(6), dp(6));
        floatingPanel.setBackground(round(0xF01A1B20, 16));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(4), 0, dp(4), 0);
        toolbar.setBackground(round(0xFF24262D, 12));

        title = text("WG  MAPPER", 15, Color.WHITE);
        title.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1));

        Button open = miniButton("☰");
        open.setContentDescription("Open mapper menu");
        open.setOnClickListener(v -> {
            menuOpen = !menuOpen;
            updatePanel();
        });
        toolbar.addView(open, new LinearLayout.LayoutParams(dp(48), dp(48)));

        floatingPanel.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(54)));

        menuPanel = new LinearLayout(this);
        menuPanel.setOrientation(LinearLayout.VERTICAL);
        menuPanel.setPadding(dp(4), dp(6), dp(4), dp(4));
        floatingPanel.addView(menuPanel, new LinearLayout.LayoutParams(-1, -2));

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                dp(170),
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = dp(40);

        try {
            wm.addView(floatingPanel, lp);
        } catch (Throwable t) {
            floatingPanel = null;
        }
    }

    private void updatePanel() {
        if (floatingPanel == null || menuPanel == null) return;
        menuPanel.removeAllViews();
        menuPanel.setVisibility(menuOpen ? View.VISIBLE : View.GONE);

        String game = targetPackage == null ? "GAME" : targetPackage;
        if (waitingForAssignment) {
            title.setText("WG  ASSIGNING...");
        } else if (editMode) {
            title.setText("WG  EDIT MODE");
        } else {
            title.setText("WG  MAPPER");
        }

        if (!menuOpen) return;

        status = text(
                waitingForAssignment
                        ? "PRESS THE GAMEPAD BUTTON TO ASSIGN"
                        : "Mapping: " + game,
                11,
                waitingForAssignment ? 0xFFFFC107 : 0xFFBFC5D2);
        status.setPadding(dp(10), dp(8), dp(10), dp(8));
        menuPanel.addView(status, new LinearLayout.LayoutParams(-1, -2));

        Button add = menuButton("＋  ADD BUTTON");
        add.setOnClickListener(v -> beginAssignment());
        menuPanel.addView(add);

        Button mouse = menuButton(profile != null && profile.hasMouseZone
                ? "✓  MOUSE ZONE"
                : "＋  MOUSE ZONE");
        mouse.setOnClickListener(v -> {
            if (profile != null) {
                profile.hasMouseZone = true;
                ProfileStore.saveProfile(this, targetPackage, profile);
                editMode = true;
                menuOpen = false;
                renderTouchLayer();
                updatePanel();
            }
        });
        menuPanel.addView(mouse);

        Button hide = menuButton(hideTouchButtons ? "SHOW TOUCH BUTTONS" : "HIDE TOUCH BUTTONS");
        hide.setOnClickListener(v -> {
            hideTouchButtons = !hideTouchButtons;
            renderTouchLayer();
            updatePanel();
        });
        menuPanel.addView(hide);

        Button lock = menuButton(editMode ? "LOCK MAPPING" : "EDIT / DRAG BUTTONS");
        lock.setOnClickListener(v -> {
            editMode = !editMode;
            menuOpen = false;
            renderTouchLayer();
            updatePanel();
        });
        menuPanel.addView(lock);

        Button mouseModeButton = menuButton(mouseMode ? "MOUSE MODE: ON" : "MOUSE MODE: OFF");
        mouseModeButton.setOnClickListener(v -> {
            mouseMode = !mouseMode;
            menuOpen = false;
            updatePanel();
        });
        menuPanel.addView(mouseModeButton);

        Button save = menuButton("SAVE PROFILE");
        save.setOnClickListener(v -> {
            if (profile != null) ProfileStore.saveProfile(this, targetPackage, profile);
            Toast.makeText(this, "Mapping saved", Toast.LENGTH_SHORT).show();
        });
        menuPanel.addView(save);

        Button close = menuButton("CLOSE MAPPER");
        close.setOnClickListener(v -> hideOverlay());
        menuPanel.addView(close);
    }

    private void beginAssignment() {
        waitingForAssignment = true;
        editMode = true;
        menuOpen = true;
        updatePanel();
        renderTouchLayer();
    }

    private void renderTouchLayer() {
        if (touchLayer == null) return;

        touchLayer.removeAllViews();
        WindowManager.LayoutParams lp = (WindowManager.LayoutParams) touchLayer.getLayoutParams();
        if (lp != null) {
            if (editMode) {
                lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            } else {
                lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            }
            try {
                wm.updateViewLayout(touchLayer, lp);
            } catch (Throwable ignored) {}
        }

        if (profile == null || hideTouchButtons) return;

        if (profile.hasMouseZone) {
            addMouseZoneView();
        }

        for (MappingProfile.Control c : profile.controls.values()) {
            if (c == null || c.keyCode == KeyEvent.KEYCODE_UNKNOWN) continue;
            addControlView(c);
        }
    }

    private void addControlView(MappingProfile.Control c) {
        Button b = miniButton(c.label);
        b.setTextSize(12);
        b.setTextColor(Color.WHITE);
        b.setBackground(roundStroke(0xB52D3440, 0xFFE8EDF5, 2, 100));
        b.setGravity(Gravity.CENTER);
        b.setContentDescription("Mapped controller button " + c.label);

        int width = getResources().getDisplayMetrics().widthPixels;
        int height = getResources().getDisplayMetrics().heightPixels;
        int size = Math.max(dp(50), (int) (c.size * width));

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(size, size);
        touchLayer.addView(b, cp);

        touchLayer.post(() -> {
            cp.leftMargin = clamp((int) (c.x * width - size / 2f), 0, Math.max(0, width - size));
            cp.topMargin = clamp((int) (c.y * height - size / 2f), 0, Math.max(0, height - size));
            b.setLayoutParams(cp);
        });

        if (editMode) {
            makeDraggable(b, cp, c);
        } else {
            b.setClickable(false);
            b.setFocusable(false);
        }
    }

    private void addMouseZoneView() {
        TextView zone = text("RIGHT STICK\nMOUSE ZONE", 11, 0xFFDDEEFF);
        zone.setGravity(Gravity.CENTER);
        zone.setBackground(roundStroke(0x3027A7FF, 0xFF66C8FF, 2, 18));

        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        int left = (int) (profile.mouseZone.left * w);
        int top = (int) (profile.mouseZone.top * h);
        int width = Math.max(dp(160), (int) (profile.mouseZone.width() * w));
        int height = Math.max(dp(120), (int) (profile.mouseZone.height() * h));

        FrameLayout.LayoutParams zp = new FrameLayout.LayoutParams(width, height);
        zp.leftMargin = left;
        zp.topMargin = top;
        touchLayer.addView(zone, zp);

        if (editMode) {
            zone.setOnTouchListener(new View.OnTouchListener() {
                float downX, downY;
                float startL, startT;

                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    if (e.getAction() == MotionEvent.ACTION_DOWN) {
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startL = profile.mouseZone.left;
                        startT = profile.mouseZone.top;
                        return true;
                    }
                    if (e.getAction() == MotionEvent.ACTION_MOVE) {
                        float dx = (e.getRawX() - downX) / Math.max(1, w);
                        float dy = (e.getRawY() - downY) / Math.max(1, h);
                        float zw = profile.mouseZone.width();
                        float zh = profile.mouseZone.height();
                        float nl = clamp(startL + dx, 0, 1 - zw);
                        float nt = clamp(startT + dy, 0, 1 - zh);
                        profile.mouseZone.set(nl, nt, nl + zw, nt + zh);
                        zp.leftMargin = (int) (nl * w);
                        zp.topMargin = (int) (nt * h);
                        v.setLayoutParams(zp);
                        return true;
                    }
                    if (e.getAction() == MotionEvent.ACTION_UP) {
                        ProfileStore.saveProfile(MapperAccessibilityService.this, targetPackage, profile);
                        return true;
                    }
                    return true;
                }
            });
        } else {
            zone.setClickable(false);
        }
    }

    private void makeDraggable(View v, FrameLayout.LayoutParams lp, MappingProfile.Control c) {
        v.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            float startX, startY;

            @Override
            public boolean onTouch(View view, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX = e.getRawX();
                    downY = e.getRawY();
                    startX = lp.leftMargin;
                    startY = lp.topMargin;
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    int maxX = Math.max(0, getResources().getDisplayMetrics().widthPixels - view.getWidth());
                    int maxY = Math.max(0, getResources().getDisplayMetrics().heightPixels - view.getHeight());
                    lp.leftMargin = clamp((int) (startX + e.getRawX() - downX), 0, maxX);
                    lp.topMargin = clamp((int) (startY + e.getRawY() - downY), 0, maxY);
                    view.setLayoutParams(lp);
                    c.x = (lp.leftMargin + view.getWidth() / 2f)
                            / Math.max(1, getResources().getDisplayMetrics().widthPixels);
                    c.y = (lp.topMargin + view.getHeight() / 2f)
                            / Math.max(1, getResources().getDisplayMetrics().heightPixels);
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    ProfileStore.saveProfile(MapperAccessibilityService.this, targetPackage, profile);
                    return true;
                }
                return true;
            }
        });
    }

    @Override
    public boolean onKeyEvent(KeyEvent event) {
        if (event == null || profile == null) return false;

        InputDevice device = event.getDevice();
        if (device == null || !isController(device)) return false;
        if (event.getRepeatCount() > 0) return true;

        // ADD BUTTON mode: consume the next controller key and bind it.
        if (waitingForAssignment && event.getAction() == KeyEvent.ACTION_DOWN) {
            int key = event.getKeyCode();
            if (key != KeyEvent.KEYCODE_UNKNOWN && key != KeyEvent.KEYCODE_BACK) {
                // One physical button can have only one mapping in this profile.
                profile.controls.remove(key);
                MappingProfile.Control c = new MappingProfile.Control(key, KeyNames.nameFor(key), 0.5f, 0.5f);
                profile.controls.put(key, c);
                waitingForAssignment = false;
                editMode = true;
                ProfileStore.saveProfile(this, targetPackage, profile);
                renderTouchLayer();
                updatePanel();
                Toast.makeText(this, "Assigned " + c.label + ". Drag it over the game's button.", Toast.LENGTH_LONG).show();
                return true;
            }
        }

        if (waitingForAssignment) return true;

        String current = targetPackage;
        if (getRootInActiveWindow() != null && getRootInActiveWindow().getPackageName() != null) {
            current = getRootInActiveWindow().getPackageName().toString();
        }
        if (targetPackage != null && current != null && !targetPackage.equals(current)) {
            return false;
        }

        int key = event.getKeyCode();

        // Mouse-zone fallback: D-pad moves a virtual cursor inside the configured
        // zone and A performs a click. This works with controllers that expose
        // the stick as motion axes only inside the foreground app; true global
        // analog-stick capture is a separate privileged input layer.
        if (mouseMode && profile.hasMouseZone && event.getAction() == KeyEvent.ACTION_DOWN) {
            if (key == KeyEvent.KEYCODE_DPAD_UP) { moveMouse(0f, -0.035f); return true; }
            if (key == KeyEvent.KEYCODE_DPAD_DOWN) { moveMouse(0f, 0.035f); return true; }
            if (key == KeyEvent.KEYCODE_DPAD_LEFT) { moveMouse(-0.035f, 0f); return true; }
            if (key == KeyEvent.KEYCODE_DPAD_RIGHT) { moveMouse(0.035f, 0f); return true; }
            if (key == KeyEvent.KEYCODE_BUTTON_A) { dispatchTap(mouseX, mouseY); return true; }
        }

        MappingProfile.Control c = profile.controls.get(key);

        if (c != null && event.getAction() == KeyEvent.ACTION_DOWN) {
            dispatchTap(c.x, c.y);
            return true;
        }

        return false;
    }

    private boolean isController(InputDevice d) {
        int sources = d.getSources();
        return (sources & InputDevice.SOURCE_GAMEPAD) != 0
                || (sources & InputDevice.SOURCE_JOYSTICK) != 0;
    }

    private void moveMouse(float dx, float dy) {
        RectF z = profile.mouseZone;
        mouseX = clamp(mouseX + dx * profile.mouseSensitivity, z.left, z.right);
        mouseY = clamp(mouseY + dy * profile.mouseSensitivity, z.top, z.bottom);
        dispatchTap(mouseX, mouseY);
        if (status != null) {
            status.setText(String.format(Locale.US, "MOUSE %.0f%% %.0f%%", mouseX * 100f, mouseY * 100f));
        }
    }

    private void dispatchTap(float nx, float ny) {
        if (Build.VERSION.SDK_INT < 24) return;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float x = clamp(nx, 0, 1) * dm.widthPixels;
        float y = clamp(ny, 0, 1) * dm.heightPixels;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 55);
        dispatchGesture(
                new GestureDescription.Builder().addStroke(stroke).build(),
                null,
                null);
    }

    private Button miniButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(10);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        return b;
    }

    private Button menuButton(String label) {
        Button b = miniButton(label);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setPadding(dp(12), 0, dp(8), 0);
        b.setBackground(round(0xFF292C34, 10));
        b.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(46)));
        return b;
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private GradientDrawable roundStroke(int fill, int stroke, int width, int radiusDp) {
        GradientDrawable g = round(fill, radiusDp);
        g.setStroke(dp(width), stroke);
        return g;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private void hideOverlay() {
        waitingForAssignment = false;
        menuOpen = false;
        if (touchLayer != null) {
            try { wm.removeView(touchLayer); } catch (Throwable ignored) {}
        }
        if (floatingPanel != null) {
            try { wm.removeView(floatingPanel); } catch (Throwable ignored) {}
        }
        touchLayer = null;
        floatingPanel = null;
        menuPanel = null;
        status = null;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Keep the overlay alive while the selected game is in the foreground.
        // If another app becomes foreground, input mapping is simply not injected.
    }

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        hideOverlay();
        instance = null;
        super.onDestroy();
    }
}
