package com.nova00p.weirdgamepadlauncher;

import android.graphics.drawable.Drawable;

public class GameInfo {
    public final String name;
    public final String packageName;
    public final Drawable icon;

    public GameInfo(String name, String packageName, Drawable icon) {
        this.name = name;
        this.packageName = packageName;
        this.icon = icon;
    }
}
