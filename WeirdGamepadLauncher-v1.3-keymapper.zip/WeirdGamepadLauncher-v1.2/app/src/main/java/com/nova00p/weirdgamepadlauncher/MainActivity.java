package com.nova00p.weirdgamepadlauncher;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    private LinearLayout gameList;
    private ProgressBar progress;
    private TextView enhancedStatus;
    private final List<GameInfo> games = new ArrayList<>();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gameList = findViewById(R.id.gameList);
        progress = findViewById(R.id.progress);
        enhancedStatus = findViewById(R.id.enhancedStatus);

        findViewById(R.id.enhancedButton).setOnClickListener(v -> setupEnhanced());
        findViewById(R.id.testPadButton).setOnClickListener(v ->
                startActivity(new Intent(this, TestPadActivity.class)));
        findViewById(R.id.settingsButton).setOnClickListener(v -> setupEnhanced());

        EditText search = findViewById(R.id.search);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ render(s.toString()); }
            public void afterTextChanged(Editable e){}
        });

        loadGames();
        updateEnhancedStatus();
    }

    @Override protected void onResume() {
        super.onResume();
        updateEnhancedStatus();
    }

    private void updateEnhancedStatus() {
        boolean running = ShizukuHelper.isRunning();
        boolean allowed = ShizukuHelper.hasPermission();
        enhancedStatus.setText(running && allowed ? "ENHANCED • READY" :
                running ? "ENHANCED • PERMISSION" : "ENHANCED • OFF");
    }

    private void setupEnhanced() {
        if (!ShizukuHelper.isRunning()) {
            new AlertDialog.Builder(this)
                    .setTitle("Enhanced Mode")
                    .setMessage("Shizuku is not running. Start Shizuku first, then return here.")
                    .setPositiveButton("OPEN SHIZUKU", (d,w) -> ShizukuHelper.openShizuku(this))
                    .setNegativeButton("CANCEL", null).show();
            return;
        }
        if (!ShizukuHelper.hasPermission()) {
            ShizukuHelper.requestPermission();
            Toast.makeText(this, "Shizuku permission requested.", Toast.LENGTH_SHORT).show();
        } else {
            startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS));
        }
    }

    private void loadGames() {
        progress.setVisibility(View.VISIBLE);
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            Intent launcher = new Intent(Intent.ACTION_MAIN);
            launcher.addCategory(Intent.CATEGORY_LAUNCHER);
            List<android.content.pm.ResolveInfo> infos = pm.queryIntentActivities(launcher, PackageManager.MATCH_ALL);
            List<GameInfo> found = new ArrayList<>();

            for (android.content.pm.ResolveInfo ri : infos) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName())) continue;
                ApplicationInfo ai = ri.activityInfo.applicationInfo;
                CharSequence label = pm.getApplicationLabel(ai);
                Drawable icon = pm.getApplicationIcon(ai);
                found.add(new GameInfo(label == null ? pkg : label.toString(), pkg, icon));
            }

            found.sort(Comparator.comparing(a -> a.name.toLowerCase(Locale.ROOT)));
            runOnUiThread(() -> {
                games.clear();
                games.addAll(found);
                progress.setVisibility(View.GONE);
                render("");
            });
        }).start();
    }

    private void render(String query) {
        String q = query.trim().toLowerCase(Locale.ROOT);
        gameList.removeAllViews();

        for (GameInfo game : games) {
            if (!q.isEmpty() && !game.name.toLowerCase(Locale.ROOT).contains(q)) continue;
            View row = getLayoutInflater().inflate(R.layout.item_game, gameList, false);
            ((ImageView) row.findViewById(R.id.icon)).setImageDrawable(game.icon);
            ((TextView) row.findViewById(R.id.name)).setText(game.name);
            ((TextView) row.findViewById(R.id.packageName)).setText(game.packageName);
            row.findViewById(R.id.play).setOnClickListener(v -> openGame(game));
            row.setOnClickListener(v -> openGame(game));
            gameList.addView(row);
        }
    }

    private void openGame(GameInfo game) {
        Intent i = new Intent(this, GameActivity.class);
        i.putExtra("name", game.name);
        i.putExtra("package", game.packageName);
        startActivity(i);
    }
}
