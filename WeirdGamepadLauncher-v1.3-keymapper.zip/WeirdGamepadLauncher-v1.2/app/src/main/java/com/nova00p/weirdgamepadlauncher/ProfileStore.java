package com.nova00p.weirdgamepadlauncher;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.RectF;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Map;

public final class ProfileStore {
    private static final String PREF = "mapping_profiles_v2";
    private static final String KEY = "profile_";

    private ProfileStore() {}

    public static MappingProfile loadProfile(Context context, String packageName) {
        MappingProfile profile = new MappingProfile();
        SharedPreferences prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY + packageName, null);
        if (raw == null || raw.isEmpty()) return profile;
        try {
            JSONObject root = new JSONObject(raw);
            profile.mouseSensitivity = (float) root.optDouble("mouseSensitivity", 1.0);
            JSONObject zone = root.optJSONObject("mouseZone");
            if (zone != null) {
                profile.mouseZone = new RectF(
                        (float) zone.optDouble("l", 0.10),
                        (float) zone.optDouble("t", 0.20),
                        (float) zone.optDouble("r", 0.90),
                        (float) zone.optDouble("b", 0.80));
                profile.hasMouseZone = root.optBoolean("hasMouseZone", true);
            }
            JSONArray controls = root.optJSONArray("controls");
            if (controls != null) {
                for (int i = 0; i < controls.length(); i++) {
                    JSONObject c = controls.optJSONObject(i);
                    if (c == null) continue;
                    int key = c.optInt("key", -1);
                    if (key < 0) continue;
                    MappingProfile.Control control = new MappingProfile.Control(
                            key,
                            c.optString("label", KeyNames.nameFor(key)),
                            (float) c.optDouble("x", 0.5),
                            (float) c.optDouble("y", 0.5));
                    control.type = c.optString("type", MappingProfile.TYPE_TAP);
                    control.size = (float) c.optDouble("size", 0.075);
                    profile.controls.put(key, control);
                }
            }
        } catch (Exception ignored) {
            return new MappingProfile();
        }
        return profile;
    }

    public static void saveProfile(Context context, String packageName, MappingProfile profile) {
        try {
            JSONObject root = new JSONObject();
            root.put("mouseSensitivity", profile.mouseSensitivity);
            root.put("hasMouseZone", profile.hasMouseZone);
            JSONObject zone = new JSONObject();
            zone.put("l", profile.mouseZone.left);
            zone.put("t", profile.mouseZone.top);
            zone.put("r", profile.mouseZone.right);
            zone.put("b", profile.mouseZone.bottom);
            root.put("mouseZone", zone);

            JSONArray controls = new JSONArray();
            for (Map.Entry<Integer, MappingProfile.Control> e : profile.controls.entrySet()) {
                MappingProfile.Control c = e.getValue();
                JSONObject obj = new JSONObject();
                obj.put("key", c.keyCode);
                obj.put("label", c.label);
                obj.put("type", c.type);
                obj.put("x", c.x);
                obj.put("y", c.y);
                obj.put("size", c.size);
                controls.put(obj);
            }
            root.put("controls", controls);
            context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .edit().putString(KEY + packageName, root.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static boolean exists(Context context, String packageName) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .contains(KEY + packageName);
    }
}
