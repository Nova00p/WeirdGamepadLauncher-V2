package com.nova00p.weirdgamepadlauncher;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class GameActivity extends AppCompatActivity {
    private String packageName;
    private String gameName;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        gameName = getIntent().getStringExtra("name");
        packageName = getIntent().getStringExtra("package");

        ((TextView)findViewById(R.id.gameName)).setText(gameName);
        ((TextView)findViewById(R.id.gamePackage)).setText(packageName);
        ((TextView)findViewById(R.id.scanStatus)).setText(
                "PROFILE READY\n\nGamepad mapper: editable\n" +
                "Per-game profile: " + (ProfileStore.exists(this, packageName) ? "SAVED" : "NOT SAVED") +
                "\n\nUse EDIT GAMEPAD MAPPING to place touch controls and bind them to controller buttons.");

        findViewById(R.id.playButton).setOnClickListener(v -> launchGame());
        findViewById(R.id.mapButton).setOnClickListener(v -> openMapperEditor());
        findViewById(R.id.overlayButton).setOnClickListener(v -> startMapper());
        findViewById(R.id.backButton).setOnClickListener(v -> finish());
    }

    private void launchGame() {
        if (ProfileStore.exists(this, packageName)) {
            if (MapperAccessibilityService.isRunning()) {
                MapperAccessibilityService.startOverlay(this, packageName);
            } else {
                Toast.makeText(this, "Enable Enhanced Mode/accessibility before using the mapper.", Toast.LENGTH_LONG).show();
            }
        }
        Intent i = getPackageManager().getLaunchIntentForPackage(packageName);
        if (i == null) {
            Toast.makeText(this, "Game launch activity not found.", Toast.LENGTH_SHORT).show();
            return;
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void openMapperEditor() {
        Intent i = new Intent(this, MappingEditorActivity.class);
        i.putExtra("name", gameName);
        i.putExtra("package", packageName);
        startActivity(i);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void startMapper() {
        if (!MapperAccessibilityService.isRunning()) {
            new AlertDialog.Builder(this)
                    .setTitle("Enhanced Mode")
                    .setMessage("Enable WeirdGamepad Launcher in Android Accessibility settings. This service is used for the floating mapper and touch gesture injection.")
                    .setPositiveButton("OPEN SETTINGS", (d, w) -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                    .setNegativeButton("CANCEL", null)
                    .show();
            return;
        }
        MapperAccessibilityService.startOverlay(this, packageName);
        Toast.makeText(this, "Floating mapper started.", Toast.LENGTH_SHORT).show();
    }
}
