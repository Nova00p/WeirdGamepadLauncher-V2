package com.nova00p.weirdgamepadlauncher;

import android.graphics.Color;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
import java.util.List;

/**
 * Optional full-screen profile editor. The normal workflow is the floating mapper:
 * ADD BUTTON -> press controller button -> drag the assigned marker over the game UI.
 */
public class MappingEditorActivity extends AppCompatActivity {
    private String packageName;
    private String gameName;
    private MappingProfile profile;
    private FrameLayout canvas;
    private MappingProfile.Control selectedControl;
    private boolean waitingForAssignment = false;
    private TextView help;

    private final List<Integer> keys = Arrays.asList(
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B,
            KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
            KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_R1,
            KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2,
            KeyEvent.KEYCODE_BUTTON_THUMBL, KeyEvent.KEYCODE_BUTTON_THUMBR,
            KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT,
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        packageName = getIntent().getStringExtra("package");
        gameName = getIntent().getStringExtra("name");
        if (gameName == null) gameName = "Game";
        profile = ProfileStore.loadProfile(this, packageName);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0D0F14);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), dp(6), dp(10), dp(6));

        TextView title = label("MAPPER  •  " + gameName, 18, Color.WHITE);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(54), 1));

        Button save = button("SAVE");
        save.setOnClickListener(v -> {
            ProfileStore.saveProfile(this, packageName, profile);
            Toast.makeText(this, "Mapping saved", Toast.LENGTH_SHORT).show();
        });
        bar.addView(save, new LinearLayout.LayoutParams(dp(90), dp(50)));

        Button done = button("DONE");
        done.setOnClickListener(v -> finish());
        bar.addView(done, new LinearLayout.LayoutParams(dp(90), dp(50)));
        root.addView(bar);

        help = label(
                "ADD BUTTON → press a gamepad button → drag the new marker over the game's touch button.\n" +
                        "The saved profile is used by the floating mapper when this game is launched.",
                12, 0xFFB8BEC9);
        help.setPadding(dp(12), dp(5), dp(12), dp(8));
        root.addView(help);

        canvas = new FrameLayout(this);
        canvas.setBackgroundColor(0xFF20242D);
        root.addView(canvas, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout palette = new LinearLayout(this);
        palette.setGravity(Gravity.CENTER_VERTICAL);
        palette.setPadding(dp(6), dp(6), dp(6), dp(6));
        palette.setOrientation(LinearLayout.HORIZONTAL);

        Button add = button("＋ ADD BUTTON");
        add.setOnClickListener(v -> beginAssignment());
        palette.addView(add, new LinearLayout.LayoutParams(dp(130), dp(48)));

        Button mouse = button(profile.hasMouseZone ? "MOUSE ZONE ✓" : "＋ MOUSE ZONE");
        mouse.setOnClickListener(v -> {
            profile.hasMouseZone = true;
            renderCanvas();
        });
        palette.addView(mouse, new LinearLayout.LayoutParams(dp(130), dp(48)));

        Button clear = button("CLEAR");
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Clear mapping?")
                .setMessage("Remove all mapped controller buttons for this game?")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("CLEAR", (d, w) -> {
                    profile.controls.clear();
                    renderCanvas();
                }).show());
        palette.addView(clear, new LinearLayout.LayoutParams(dp(100), dp(48)));

        root.addView(palette, new LinearLayout.LayoutParams(-1, dp(60)));
        setContentView(root);
        renderCanvas();
    }

    private void beginAssignment() {
        waitingForAssignment = true;
        selectedControl = null;
        help.setText("ASSIGN MODE: press the physical gamepad button you want to map.\nThe new marker will appear at the centre and can then be dragged onto the game's touch button.");
        Toast.makeText(this, "Press the gamepad button now…", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (waitingForAssignment && event.getAction() == KeyEvent.ACTION_DOWN) {
            if (event.getDevice() != null && isController(event.getDevice())) {
                int key = event.getKeyCode();
                if (key != KeyEvent.KEYCODE_UNKNOWN) {
                    profile.controls.remove(key);
                    selectedControl = new MappingProfile.Control(key, KeyNames.nameFor(key), 0.5f, 0.5f);
                    profile.controls.put(key, selectedControl);
                    waitingForAssignment = false;
                    ProfileStore.saveProfile(this, packageName, profile);
                    help.setText("Assigned " + selectedControl.label + ". Drag it over the game's touch control, then SAVE.");
                    renderCanvas();
                    Toast.makeText(this, "Assigned " + selectedControl.label, Toast.LENGTH_SHORT).show();
                    return true;
                }
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private void renderCanvas() {
        if (canvas == null) return;
        canvas.removeAllViews();
        if (profile.hasMouseZone) renderMouseZone();
        for (MappingProfile.Control c : profile.controls.values()) {
            addControlView(c);
        }
    }

    private void addControlView(MappingProfile.Control c) {
        TextView v = label(c.label, 13, Color.WHITE);
        v.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xAA3A4150);
        bg.setStroke(2, 0xFFE2E7F0);
        bg.setCornerRadius(100);
        v.setBackground(bg);

        int size = dp(58);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(size, size);
        canvas.addView(v, lp);
        canvas.post(() -> place(lp, c.x, c.y, size));

        v.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY, startX, startY;
            @Override
            public boolean onTouch(View view, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    selectedControl = c;
                    downX = e.getRawX();
                    downY = e.getRawY();
                    startX = lp.leftMargin;
                    startY = lp.topMargin;
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    lp.leftMargin = clamp((int) (startX + e.getRawX() - downX), 0, Math.max(0, canvas.getWidth() - view.getWidth()));
                    lp.topMargin = clamp((int) (startY + e.getRawY() - downY), 0, Math.max(0, canvas.getHeight() - view.getHeight()));
                    view.setLayoutParams(lp);
                    c.x = (lp.leftMargin + view.getWidth() / 2f) / Math.max(1, canvas.getWidth());
                    c.y = (lp.topMargin + view.getHeight() / 2f) / Math.max(1, canvas.getHeight());
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    ProfileStore.saveProfile(MappingEditorActivity.this, packageName, profile);
                    return true;
                }
                return true;
            }
        });
    }

    private void renderMouseZone() {
        TextView zone = label("RIGHT STICK\nMOUSE ZONE", 12, 0xFFE8EDF5);
        zone.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x3327A7FF);
        bg.setStroke(2, 0xFF6FC7FF);
        bg.setCornerRadius(dp(18));
        zone.setBackground(bg);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(0, 0);
        canvas.addView(zone, lp);
        canvas.post(() -> {
            lp.leftMargin = (int) (profile.mouseZone.left * canvas.getWidth());
            lp.topMargin = (int) (profile.mouseZone.top * canvas.getHeight());
            lp.width = Math.max(dp(160), (int) (profile.mouseZone.width() * canvas.getWidth()));
            lp.height = Math.max(dp(120), (int) (profile.mouseZone.height() * canvas.getHeight()));
            zone.setLayoutParams(lp);
        });

        zone.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            float startL, startT;
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX = e.getRawX();
                    downY = e.getRawY();
                    startL = profile.mouseZone.left;
                    startT = profile.mouseZone.top;
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    float dx = (e.getRawX() - downX) / Math.max(1, canvas.getWidth());
                    float dy = (e.getRawY() - downY) / Math.max(1, canvas.getHeight());
                    float w = profile.mouseZone.width();
                    float h = profile.mouseZone.height();
                    float nl = clampF(startL + dx, 0, 1 - w);
                    float nt = clampF(startT + dy, 0, 1 - h);
                    profile.mouseZone.set(nl, nt, nl + w, nt + h);
                    FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) v.getLayoutParams();
                    p.leftMargin = (int) (nl * canvas.getWidth());
                    p.topMargin = (int) (nt * canvas.getHeight());
                    v.setLayoutParams(p);
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    ProfileStore.saveProfile(MappingEditorActivity.this, packageName, profile);
                    return true;
                }
                return true;
            }
        });
    }

    private void place(FrameLayout.LayoutParams lp, float x, float y, int size) {
        lp.leftMargin = clamp((int) (x * canvas.getWidth() - size / 2f), 0, Math.max(0, canvas.getWidth() - size));
        lp.topMargin = clamp((int) (y * canvas.getHeight() - size / 2f), 0, Math.max(0, canvas.getHeight() - size));
    }

    private boolean isController(android.view.InputDevice d) {
        int s = d.getSources();
        return (s & android.view.InputDevice.SOURCE_GAMEPAD) != 0 || (s & android.view.InputDevice.SOURCE_JOYSTICK) != 0;
    }

    private TextView label(String text, int size, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        return b;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    private float clampF(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }
}
