package com.nova00p.weirdgamepadlauncher;

import android.os.Bundle;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class TestPadActivity extends AppCompatActivity {
    private TextView deviceText, buttonText, stickText;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testpad);
        deviceText=findViewById(R.id.deviceText);
        buttonText=findViewById(R.id.buttonText);
        stickText=findViewById(R.id.stickText);
        findViewById(R.id.back).setOnClickListener(v -> finish());
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        InputDevice d=event.getDevice();
        if (d != null && isController(d)) {
            deviceText.setText("Connected: " + d.getName() + "\nID: " + d.getId());
            String action=event.getAction()==KeyEvent.ACTION_DOWN ? "DOWN" : "UP";
            buttonText.setText("Button: " + KeyNames.nameFor(event.getKeyCode()) +
                    "\nCode: " + event.getKeyCode() + "\nAction: " + action);
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public boolean dispatchGenericMotionEvent(MotionEvent event) {
        InputDevice d=event.getDevice();
        if (d != null && isController(d) &&
                (event.getSource() & InputDevice.SOURCE_JOYSTICK) != 0) {
            deviceText.setText("Connected: " + d.getName() + "\nID: " + d.getId());
            float lx=axis(event, MotionEvent.AXIS_X);
            float ly=axis(event, MotionEvent.AXIS_Y);
            float rx=axis(event, MotionEvent.AXIS_RX, MotionEvent.AXIS_Z);
            float ry=axis(event, MotionEvent.AXIS_RY, MotionEvent.AXIS_RZ);
            float lt=axis(event, MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_BRAKE);
            float rt=axis(event, MotionEvent.AXIS_RTRIGGER, MotionEvent.AXIS_GAS);
            float hx=axis(event, MotionEvent.AXIS_HAT_X);
            float hy=axis(event, MotionEvent.AXIS_HAT_Y);
            stickText.setText(String.format(Locale.US,
                    "LEFT STICK   X %.2f   Y %.2f\nRIGHT STICK  X %.2f   Y %.2f\n" +
                    "L2 TRIGGER   %.2f\nR2 TRIGGER   %.2f\nD-PAD AXIS   X %.2f   Y %.2f",
                    lx,ly,rx,ry,lt,rt,hx,hy));
            buttonText.setText("Motion event detected");
            return true;
        }
        return super.dispatchGenericMotionEvent(event);
    }

    private float axis(MotionEvent e, int... axes) {
        for (int axis : axes) {
            if (e.getDevice().getMotionRange(axis, e.getSource()) != null) return e.getAxisValue(axis);
        }
        return 0f;
    }

    private boolean isController(InputDevice d) {
        int s=d.getSources();
        return (s & InputDevice.SOURCE_GAMEPAD)!=0 || (s & InputDevice.SOURCE_JOYSTICK)!=0;
    }
}
