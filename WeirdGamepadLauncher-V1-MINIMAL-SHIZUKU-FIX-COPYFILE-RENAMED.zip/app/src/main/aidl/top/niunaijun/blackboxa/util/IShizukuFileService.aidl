package top.niunaijun.blackboxa.util;

interface IShizukuFileService {
    String[] getApkPaths(String packageName);
    void stageFile(String sourcePath, String targetPath);
}
