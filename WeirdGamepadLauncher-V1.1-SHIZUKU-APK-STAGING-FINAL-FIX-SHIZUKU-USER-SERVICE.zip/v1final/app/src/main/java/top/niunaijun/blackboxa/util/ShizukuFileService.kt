package top.niunaijun.blackboxa.util

import android.os.ParcelFileDescriptor
import java.io.File

/**
 * Runs inside a Shizuku UserService (shell/root identity).
 * Only performs the privileged APK path lookup/open operations needed by staging.
 */
class ShizukuFileService : IShizukuFileService.Stub() {
    override fun getApkPaths(packageName: String): Array<String> {
        require(packageName.matches(Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+$")))
        val process = ProcessBuilder("pm", "path", packageName)
            .redirectErrorStream(false)
            .start()
        val output = process.inputStream.bufferedReader().use { it.readText() }
        val error = process.errorStream.bufferedReader().use { it.readText() }
        val code = process.waitFor()
        if (code != 0) throw IllegalStateException("pm path failed ($code): ${error.trim()}")
        return output.lineSequence()
            .map { it.trim() }
            .filter { it.startsWith("package:/") }
            .map { it.removePrefix("package:") }
            .distinct()
            .toList()
            .toTypedArray()
    }

    override fun openFile(path: String): ParcelFileDescriptor {
        require(path.startsWith("/data/app/") || path.startsWith("/product/app/") || path.startsWith("/system/app/") || path.startsWith("/system_ext/app/")) {
            "Unexpected APK path"
        }
        return ParcelFileDescriptor.open(File(path), ParcelFileDescriptor.MODE_READ_ONLY)
    }
}
