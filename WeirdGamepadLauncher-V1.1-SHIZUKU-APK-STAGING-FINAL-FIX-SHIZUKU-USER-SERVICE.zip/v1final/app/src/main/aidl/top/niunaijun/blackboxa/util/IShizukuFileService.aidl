package top.niunaijun.blackboxa.util;

import android.os.ParcelFileDescriptor;

interface IShizukuFileService {
    String[] getApkPaths(String packageName);
    ParcelFileDescriptor openFile(String path);
}
