# Android 14 Attribution Fix V5

## Root cause confirmed from the crash
The virtual ContentProviderStub was calling `ContextCompat.fixAttributionSourceState()` with `BActivityThread.getBUid()` (10001).

Android 14's system_server checks the AttributionSource UID against the real Binder caller UID. The crash showed:

`Calling uid: 11317 doesn't match source uid: 10001`

The previous V4 changes did not change this call site.

## V5 change
`ContentProviderStub` now passes `android.os.Process.myUid()` to `fixAttributionSourceState()` for the AttributionSource sent to the system provider.

This changes the exact failing path from:

`BActivityThread.getBUid()` -> 10001

to:

`Process.myUid()` -> actual virtual process UID (for example 11317)

The existing V4 attribution changes are retained.

## Important
This is an AAR-level patch because the project currently consumes Bcore as `app/libs/Bcore-release.aar`.
