# Android 14 AttributionSource Fix v3

This build patches `SystemProviderStub` so Android 12+ `ContentProvider.call()` requests replace the incoming `AttributionSource` object with a freshly constructed instance using the UID of the current virtual process (`Process.myUid()`).

The earlier v2 mutation-based fix was insufficient on the tested device because Android still received the old `source uid: 10001`.

The patch is applied directly to `app/libs/Bcore-release.aar`.
