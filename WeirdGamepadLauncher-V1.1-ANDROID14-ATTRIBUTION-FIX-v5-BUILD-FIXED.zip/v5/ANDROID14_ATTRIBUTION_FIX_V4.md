# Android 14 Attribution Fix V4

The v3 SystemProviderStub change is retained. V4 additionally fixes the lower-level attribution rewrite in the bundled Bcore AAR.

## Root cause
`ContextCompat.fixAttributionSourceState()` was writing the supplied virtual UID into Android 12+ `AttributionSourceState`. On Android 14 this can produce a Binder call where the caller UID (for example 11315) does not match the attribution source UID (10001), causing:

`SecurityException: Calling uid: 11315 doesn't match source uid: 10001`

## V4 change
The bytecode in `Bcore-release.aar/classes.jar` now uses `BlackBoxCore.getHostUid()` when rewriting the attribution source UID, instead of preserving the virtual `BUid` argument. The package name continues to use `BlackBoxCore.getHostPkg()`, and chained attribution sources are still rewritten recursively.

This is deliberately applied at the shared attribution-fix function so callers such as `ContextCompat.fix()` and `SystemProviderStub` receive the same behavior.
