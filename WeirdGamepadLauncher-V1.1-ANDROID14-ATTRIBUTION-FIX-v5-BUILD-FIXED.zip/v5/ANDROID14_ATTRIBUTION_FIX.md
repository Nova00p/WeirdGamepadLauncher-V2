# Android 14 AttributionSource crash fix v2

The previous build changed only the first argument of `SystemProviderStub.invoke()`. The
new crash still showed:

`Calling uid: 11313 doesn't match source uid: 10001`

That means the `AttributionSource` reaching the Android 14 Settings provider was not always
in the argument position that the previous patch handled.

## v2 fix

`SystemProviderStub` now scans **all Binder call arguments**. Any argument whose runtime class
contains `AttributionSource` is passed to `ContextCompat.fixAttributionSourceState()` using
`Process.myUid()`, which is the actual UID of the virtual app process.

This avoids assuming that the `AttributionSource` is always `args[0]`.

Only the bundled `app/libs/Bcore-release.aar` was changed for this v2 patch. The launcher UI,
Minecraft cloning/profile code, and APK staging code were not changed.
