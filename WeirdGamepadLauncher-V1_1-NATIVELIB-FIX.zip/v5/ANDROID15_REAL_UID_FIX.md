# Android 15 Real UID Fix

Patched the bundled Bcore `OsStub.getuid()` implementation so it preserves the real UID returned by the underlying libcore implementation instead of replacing it with BlackBox's virtual UID (for example 10001/10002).

This addresses Android 15 `AttributionSource` validation where the Binder caller is the real process UID (for example 11321) but the source UID was being rewritten to the BlackBox virtual UID.

The fix does **not** hardcode 11321. The underlying runtime UID is returned dynamically.

Previous AttributionSource proxy/reflection changes remain in the project but are no longer relied upon for this UID fix.
