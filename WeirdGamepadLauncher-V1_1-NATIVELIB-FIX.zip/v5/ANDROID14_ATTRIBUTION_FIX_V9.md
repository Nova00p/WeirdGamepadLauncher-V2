V9: direct reflection mutation of AttributionSource state, with explicit logging; Process.myUid() is passed by existing ContentProviderStub path.
