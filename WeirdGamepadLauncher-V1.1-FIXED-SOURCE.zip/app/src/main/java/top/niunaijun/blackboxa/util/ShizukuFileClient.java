package top.niunaijun.blackboxa.util;

import android.os.IBinder;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;

/** Client-side wrapper for the Shizuku UserService binder. */
public final class ShizukuFileClient {
    private static final String DESCRIPTOR = "top.niunaijun.blackboxa.util.ShizukuFileService";
    private static final int TRANSACTION_GET_APK_PATHS = IBinder.FIRST_CALL_TRANSACTION;
    private static final int TRANSACTION_OPEN_APK = IBinder.FIRST_CALL_TRANSACTION + 1;

    private final IBinder binder;

    public ShizukuFileClient(IBinder binder) {
        if (binder == null) throw new IllegalArgumentException("binder == null");
        this.binder = binder;
    }

    public String[] getApkPaths(String packageName) throws Exception {
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            data.writeInterfaceToken(DESCRIPTOR);
            data.writeString(packageName);
            binder.transact(TRANSACTION_GET_APK_PATHS, data, reply, 0);
            reply.readException();
            String[] paths = reply.createStringArray();
            return paths == null ? new String[0] : paths;
        } finally {
            reply.recycle();
            data.recycle();
        }
    }

    public ParcelFileDescriptor openApk(String sourcePath) throws Exception {
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            data.writeInterfaceToken(DESCRIPTOR);
            data.writeString(sourcePath);
            binder.transact(TRANSACTION_OPEN_APK, data, reply, 0);
            reply.readException();
            return reply.readParcelable(ParcelFileDescriptor.class.getClassLoader(), ParcelFileDescriptor.class);
        } finally {
            reply.recycle();
            data.recycle();
        }
    }
}
