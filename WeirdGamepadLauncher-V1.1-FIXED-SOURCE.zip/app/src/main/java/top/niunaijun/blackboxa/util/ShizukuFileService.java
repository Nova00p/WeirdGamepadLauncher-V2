package top.niunaijun.blackboxa.util;

import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

/**
 * Shizuku UserService binder.
 * The service runs with Shizuku's shell/root identity and only exposes
 * read-only access to installed APK files plus package-manager path lookup.
 */
public class ShizukuFileService extends Binder {
    private static final String DESCRIPTOR = "top.niunaijun.blackboxa.util.ShizukuFileService";
    private static final int TRANSACTION_GET_APK_PATHS = IBinder.FIRST_CALL_TRANSACTION;
    private static final int TRANSACTION_OPEN_APK = IBinder.FIRST_CALL_TRANSACTION + 1;
    // Shizuku UserService destroy transaction: use 16777114 in AIDL, 16777115 here.
    private static final int TRANSACTION_DESTROY = 16777115;

    @Override
    protected boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
        if (code == INTERFACE_TRANSACTION) {
            reply.writeString(DESCRIPTOR);
            return true;
        }
        if (code == TRANSACTION_GET_APK_PATHS) {
            data.enforceInterface(DESCRIPTOR);
            try {
                String[] paths = getApkPaths(data.readString());
                reply.writeNoException();
                reply.writeStringArray(paths);
            } catch (Throwable t) {
                reply.writeException(asException(t));
            }
            return true;
        }
        if (code == TRANSACTION_OPEN_APK) {
            data.enforceInterface(DESCRIPTOR);
            try {
                ParcelFileDescriptor pfd = openApk(data.readString());
                reply.writeNoException();
                reply.writeParcelable(pfd, 0);
            } catch (Throwable t) {
                reply.writeException(asException(t));
            }
            return true;
        }
        if (code == TRANSACTION_DESTROY) {
            try {
                onDestroyService();
            } catch (Throwable ignored) {
            }
            return true;
        }
        return super.onTransact(code, data, reply, flags);
    }

    private static Exception asException(Throwable t) {
        if (t instanceof Exception) return (Exception) t;
        return new RuntimeException(t);
    }

    private String[] getApkPaths(String packageName) throws Exception {
        if (packageName == null || !packageName.matches("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+$")) {
            throw new IllegalArgumentException("Invalid package name");
        }
        Process process = new ProcessBuilder("pm", "path", packageName)
                .redirectErrorStream(false).start();
        String output;
        String error;
        try (java.io.BufferedReader in = new java.io.BufferedReader(new java.io.InputStreamReader(process.getInputStream()));
             java.io.BufferedReader err = new java.io.BufferedReader(new java.io.InputStreamReader(process.getErrorStream()))) {
            output = readAll(in);
            error = readAll(err);
        }
        int code = process.waitFor();
        if (code != 0) throw new IllegalStateException("pm path failed (" + code + "): " + error.trim());
        List<String> result = new ArrayList<>();
        for (String line : output.split("\\R")) {
            line = line.trim();
            if (line.startsWith("package:/")) {
                String path = line.substring("package:".length());
                if (!result.contains(path)) result.add(path);
            }
        }
        return result.toArray(new String[0]);
    }

    private static String readAll(java.io.BufferedReader reader) throws java.io.IOException {
        StringBuilder builder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            if (builder.length() > 0) builder.append('\n');
            builder.append(line);
        }
        return builder.toString();
    }

    private ParcelFileDescriptor openApk(String sourcePath) throws FileNotFoundException {
        if (sourcePath == null || !(sourcePath.startsWith("/data/app/") ||
                sourcePath.startsWith("/product/app/") ||
                sourcePath.startsWith("/system/app/") ||
                sourcePath.startsWith("/system_ext/app/"))) {
            throw new SecurityException("Unexpected APK path");
        }
        File source = new File(sourcePath);
        if (!source.isFile()) throw new FileNotFoundException("APK source does not exist: " + sourcePath);
        return ParcelFileDescriptor.open(source, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    private void onDestroyService() {
        System.exit(0);
    }
}
