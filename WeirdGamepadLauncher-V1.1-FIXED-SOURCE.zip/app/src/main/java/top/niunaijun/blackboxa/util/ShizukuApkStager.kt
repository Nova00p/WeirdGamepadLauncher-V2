package top.niunaijun.blackboxa.util

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.util.Log
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * Extracts installed APK files using a Shizuku UserService.
 * The privileged service reads the source APK and copies it into the app cache
 * so BlackBox can read it.
 */
object ShizukuApkStager {
    const val REQUEST_CODE = 4101
    private const val TAG = "ShizukuApkStager"
    private const val SERVICE_TAG = "apk_stager"
    private const val SERVICE_VERSION = 2
    private const val TIMEOUT_SECONDS = 20L
    private val PACKAGE_REGEX = Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+$")

    fun stagePackage(context: Context, packageName: String): Result<File> {
        return try {
            require(PACKAGE_REGEX.matches(packageName)) { "Invalid package name" }
            if (Shizuku.isPreV11() || Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                error("Shizuku permission is not granted")
            }

            val service = connect(context)
                val paths = service.getApkPaths(packageName).toList()
                if (paths.isEmpty()) error("No APK paths returned by package manager")

                val root = File(context.cacheDir, "staged_apps/$packageName").apply {
                    if (exists()) deleteRecursively()
                    mkdirs()
                }

                var baseFile: File? = null
                paths.forEachIndexed { index, sourcePath ->
                    val name = if (sourcePath.endsWith("/base.apk")) "base.apk" else "split_${index}_${File(sourcePath).name}"
                    val target = File(root, name)
                    service.openApk(sourcePath).use { pfd ->
                        require(pfd != null) { "Shizuku returned no APK file descriptor" }
                        ParcelFileDescriptor.AutoCloseInputStream(pfd).use { input ->
                            FileOutputStream(target, false).use { output ->
                                input.copyTo(output, 64 * 1024)
                                output.fd.sync()
                            }
                        }
                    }
                    if (name == "base.apk") baseFile = target
                }

                require(baseFile?.exists() == true && baseFile!!.length() > 0) { "Base APK could not be staged" }
                Log.d(TAG, "Staged ${paths.size} APK(s) for $packageName at ${root.absolutePath}")
                Result.success(baseFile!!)
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to stage $packageName", t)
            Result.failure(t)
        }
    }

    private fun connect(context: Context): ShizukuFileClient {
        val args = Shizuku.UserServiceArgs(
            ComponentName(context.packageName, ShizukuFileService::class.java.name)
        )
            .tag(SERVICE_TAG)
            .version(SERVICE_VERSION)
            .processNameSuffix("apk_stager")
            .daemon(false)
            .debuggable(false)

        val binderRef = AtomicReference<ShizukuFileClient?>()
        val errorRef = AtomicReference<Throwable?>()
        val latch = CountDownLatch(1)
        val connection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                binderRef.set(ShizukuFileClient(service))
                latch.countDown()
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                if (binderRef.get() == null) latch.countDown()
            }
        }

        try {
            Shizuku.bindUserService(args, connection)
        } catch (t: Throwable) {
            errorRef.set(t)
            latch.countDown()
        }

        if (!latch.await(TIMEOUT_SECONDS, TimeUnit.SECONDS)) {
            runCatching { Shizuku.unbindUserService(args, connection, true) }
            error("Timed out waiting for Shizuku UserService")
        }
        errorRef.get()?.let { throw it }
        return binderRef.get() ?: error("Shizuku UserService did not return a binder")
    }

}
