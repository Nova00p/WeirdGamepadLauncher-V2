package com.nova00p.weirdgamepadlauncher;

import android.graphics.Color;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Arrays;
import java.util.List;

public class MappingEditorActivity extends AppCompatActivity {
    private String packageName;
    private String gameName;
    private MappingProfile profile;
    private FrameLayout canvas;
    private boolean hideTouchButtons = false;
    private MappingProfile.Control selectedControl;
    private TextView mouseZoneView;

    private final List<Integer> keys = Arrays.asList(
            android.view.KeyEvent.KEYCODE_BUTTON_A,
            android.view.KeyEvent.KEYCODE_BUTTON_B,
            android.view.KeyEvent.KEYCODE_BUTTON_X,
            android.view.KeyEvent.KEYCODE_BUTTON_Y,
            android.view.KeyEvent.KEYCODE_BUTTON_L1,
            android.view.KeyEvent.KEYCODE_BUTTON_R1,
            android.view.KeyEvent.KEYCODE_BUTTON_L2,
            android.view.KeyEvent.KEYCODE_BUTTON_R2,
            android.view.KeyEvent.KEYCODE_BUTTON_THUMBL,
            android.view.KeyEvent.KEYCODE_BUTTON_THUMBR,
            android.view.KeyEvent.KEYCODE_DPAD_UP,
            android.view.KeyEvent.KEYCODE_DPAD_DOWN,
            android.view.KeyEvent.KEYCODE_DPAD_LEFT,
            android.view.KeyEvent.KEYCODE_DPAD_RIGHT
    );

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        packageName = getIntent().getStringExtra("package");
        gameName = getIntent().getStringExtra("name");
        profile = ProfileStore.loadProfile(this, packageName);
        if (profile.controls.isEmpty()) addStarterControls();
        buildUi();
    }

    private void addStarterControls() {
        add(android.view.KeyEvent.KEYCODE_BUTTON_A, 0.84f, 0.78f); // A
        add(android.view.KeyEvent.KEYCODE_BUTTON_B, 0.90f, 0.70f); // B
        add(android.view.KeyEvent.KEYCODE_BUTTON_X, 0.78f, 0.70f); // X
        add(android.view.KeyEvent.KEYCODE_BUTTON_Y, 0.84f, 0.62f); // Y
        add(android.view.KeyEvent.KEYCODE_BUTTON_L1, 0.18f, 0.16f); // L1
        add(android.view.KeyEvent.KEYCODE_BUTTON_R1, 0.82f, 0.16f); // R1
        add(android.view.KeyEvent.KEYCODE_BUTTON_L2, 0.18f, 0.25f); // L2
        add(android.view.KeyEvent.KEYCODE_BUTTON_R2, 0.82f, 0.25f); // R2
    }

    private void add(int key, float x, float y) {
        profile.controls.put(key, new MappingProfile.Control(key, KeyNames.nameFor(key), x, y));
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(12, 14, 20));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(12, 8, 12, 8);
        TextView title = label("MAPPER  •  " + gameName, 18, Color.WHITE);
        bar.addView(title, new LinearLayout.LayoutParams(0, 58, 1));

        Button save = button("SAVE");
        save.setOnClickListener(v -> {
            ProfileStore.saveProfile(this, packageName, profile);
            Toast.makeText(this, "Mapping saved for " + gameName, Toast.LENGTH_SHORT).show();
        });
        bar.addView(save, new LinearLayout.LayoutParams(92, 52));
        Button done = button("DONE");
        done.setOnClickListener(v -> finish());
        bar.addView(done, new LinearLayout.LayoutParams(92, 52));
        root.addView(bar);

        TextView help = label("Drag buttons to the game's touch controls. Add MOUSE ZONE for right-stick mouse control.\nThis editor creates the profile; Enhanced Mode handles injection when Android permits it.", 12, 0xFFB9BEC9);
        help.setPadding(14, 4, 14, 8);
        root.addView(help);

        canvas = new FrameLayout(this);
        canvas.setBackgroundColor(0xFF202531);
        root.addView(canvas, new LinearLayout.LayoutParams(-1, 0, 1));

        ScrollView scroll = new ScrollView(this);
        LinearLayout palette = new LinearLayout(this);
        palette.setPadding(8, 8, 8, 8);
        palette.setOrientation(LinearLayout.HORIZONTAL);
        for (Integer key : keys) {
            Button b = button("+ " + KeyNames.nameFor(key));
            b.setOnClickListener(v -> addControlIfMissing(key));
            palette.addView(b, new LinearLayout.LayoutParams(92, 48));
        }
        Button addTouch = button("+ ADD TOUCH");
        addTouch.setOnClickListener(v -> addUnboundControl());
        palette.addView(addTouch, new LinearLayout.LayoutParams(120, 48));

        Button mouse = button("+ MOUSE ZONE");
        mouse.setOnClickListener(v -> {
            profile.hasMouseZone = true;
            renderCanvas();
        });
        palette.addView(mouse, new LinearLayout.LayoutParams(140, 48));
        scroll.addView(palette);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 64));

        Switch hide = new Switch(this);
        hide.setText("Hide touch buttons");
        hide.setTextColor(Color.WHITE);
        hide.setPadding(14, 0, 14, 0);
        hide.setOnCheckedChangeListener((buttonView, checked) -> {
            hideTouchButtons = checked;
            renderCanvas();
        });
        root.addView(hide, new LinearLayout.LayoutParams(-1, 52));

        setContentView(root);
        renderCanvas();
    }

    private void addUnboundControl() {
        MappingProfile.Control c = new MappingProfile.Control(android.view.KeyEvent.KEYCODE_UNKNOWN, "?", 0.5f, 0.5f);
        profile.controls.put(System.identityHashCode(c), c);
        selectedControl = c;
        renderCanvas();
        Toast.makeText(this, "Drag the ? to the touch control, then press the gamepad button you want to bind.", Toast.LENGTH_LONG).show();
    }

    @Override public boolean dispatchKeyEvent(android.view.KeyEvent event) {
        if (event.getAction() == android.view.KeyEvent.ACTION_DOWN && selectedControl != null && selectedControl.keyCode == android.view.KeyEvent.KEYCODE_UNKNOWN) {
            android.view.InputDevice device = event.getDevice();
            if (device == null || ((device.getSources() & android.view.InputDevice.SOURCE_GAMEPAD) == 0 && (device.getSources() & android.view.InputDevice.SOURCE_JOYSTICK) == 0)) return super.dispatchKeyEvent(event);
            int key = event.getKeyCode();
            if (key != android.view.KeyEvent.KEYCODE_UNKNOWN) {
                selectedControl.keyCode = key;
                selectedControl.label = KeyNames.nameFor(key);
                profile.controls.remove(System.identityHashCode(selectedControl));
                profile.controls.put(key, selectedControl);
                renderCanvas();
                Toast.makeText(this, "Bound to " + KeyNames.nameFor(key), Toast.LENGTH_SHORT).show();
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private void addControlIfMissing(int key) {
        if (!profile.controls.containsKey(key)) {
            float x = 0.5f, y = 0.5f;
            if (key == android.view.KeyEvent.KEYCODE_BUTTON_A) { x = .84f; y = .78f; }
            else if (key == android.view.KeyEvent.KEYCODE_BUTTON_B) { x = .90f; y = .70f; }
            else if (key == android.view.KeyEvent.KEYCODE_BUTTON_X) { x = .78f; y = .70f; }
            else if (key == android.view.KeyEvent.KEYCODE_BUTTON_Y) { x = .84f; y = .62f; }
            profile.controls.put(key, new MappingProfile.Control(key, KeyNames.nameFor(key), x, y));
        }
        renderCanvas();
    }

    private void renderCanvas() {
        if (canvas == null) return;
        canvas.removeAllViews();
        if (profile.hasMouseZone) renderMouseZone();
        if (hideTouchButtons) return;
        for (MappingProfile.Control c : profile.controls.values()) addControlView(c);
    }

    private void addControlView(MappingProfile.Control c) {
        TextView v = label(c.label, 13, Color.WHITE);
        v.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xAA3A4150);
        bg.setStroke(2, 0xFFE2E7F0);
        bg.setCornerRadius(100);
        v.setBackground(bg);
        int size = dp(56);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(size, size);
        canvas.addView(v, lp);
        canvas.post(() -> {
            lp.leftMargin = clamp((int) (c.x * canvas.getWidth() - size / 2f), 0, Math.max(0, canvas.getWidth() - size));
            lp.topMargin = clamp((int) (c.y * canvas.getHeight() - size / 2f), 0, Math.max(0, canvas.getHeight() - size));
            v.setLayoutParams(lp);
        });
        v.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY, startX, startY;
            public boolean onTouch(View view, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    selectedControl = c;
                    downX = e.getRawX(); downY = e.getRawY();
                    startX = lp.leftMargin; startY = lp.topMargin;
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    float nx = startX + e.getRawX() - downX;
                    float ny = startY + e.getRawY() - downY;
                    lp.leftMargin = clamp((int) nx, 0, Math.max(0, canvas.getWidth() - view.getWidth()));
                    lp.topMargin = clamp((int) ny, 0, Math.max(0, canvas.getHeight() - view.getHeight()));
                    view.setLayoutParams(lp);
                    c.x = (lp.leftMargin + view.getWidth() / 2f) / Math.max(1, canvas.getWidth());
                    c.y = (lp.topMargin + view.getHeight() / 2f) / Math.max(1, canvas.getHeight());
                    return true;
                }
                return e.getAction() == MotionEvent.ACTION_UP;
            }
        });
    }

    private void renderMouseZone() {
        mouseZoneView = label("MOUSE ZONE\nRIGHT STICK → CURSOR\nA = CLICK", 12, 0xFFE8EDF5);
        mouseZoneView.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x3327A7FF);
        bg.setStroke(2, 0xFF6FC7FF);
        bg.setCornerRadius(24);
        mouseZoneView.setBackground(bg);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(0, 0);
        canvas.addView(mouseZoneView, lp);
        canvas.post(() -> updateMouseZoneLayout(lp));
        mouseZoneView.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; float l,t,r,b;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX=e.getRawX(); downY=e.getRawY();
                    l=profile.mouseZone.left; t=profile.mouseZone.top;
                    r=profile.mouseZone.right; b=profile.mouseZone.bottom;
                    return true;
                }
                if (e.getAction()==MotionEvent.ACTION_MOVE) {
                    float dx=(e.getRawX()-downX)/Math.max(1,canvas.getWidth());
                    float dy=(e.getRawY()-downY)/Math.max(1,canvas.getHeight());
                    float w=r-l, h=b-t;
                    float nl=clampF(l+dx,0,1-w), nt=clampF(t+dy,0,1-h);
                    profile.mouseZone.set(nl,nt,nl+w,nt+h);
                    updateMouseZoneLayout((FrameLayout.LayoutParams)v.getLayoutParams());
                    return true;
                }
                return true;
            }
        });
    }

    private void updateMouseZoneLayout(FrameLayout.LayoutParams lp) {
        lp.leftMargin=(int)(profile.mouseZone.left*canvas.getWidth());
        lp.topMargin=(int)(profile.mouseZone.top*canvas.getHeight());
        lp.width=Math.max(dp(140),(int)((profile.mouseZone.right-profile.mouseZone.left)*canvas.getWidth()));
        lp.height=Math.max(dp(100),(int)((profile.mouseZone.bottom-profile.mouseZone.top)*canvas.getHeight()));
        mouseZoneView.setLayoutParams(lp);
    }

    private TextView label(String text, int size, int color) {
        TextView t=new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private Button button(String text) { Button b=new Button(this); b.setText(text); return b; }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private int clamp(int v,int min,int max){return Math.max(min,Math.min(max,v));}
    private float clampF(float v,float min,float max){return Math.max(min,Math.min(max,v));}
}
