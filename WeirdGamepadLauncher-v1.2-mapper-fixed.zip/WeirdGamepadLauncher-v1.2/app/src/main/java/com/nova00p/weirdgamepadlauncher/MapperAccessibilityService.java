package com.nova00p.weirdgamepadlauncher;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.accessibility.AccessibilityEvent;

public class MapperAccessibilityService extends AccessibilityService {
    private static MapperAccessibilityService instance;
    private WindowManager wm;
    private LinearLayout panel;
    private FrameLayout touchLayer;
    private String targetPackage;
    private MappingProfile profile;
    private boolean hideTouchButtons;
    private boolean editMode;
    private boolean mouseMode;
    private float mouseX = 0.5f, mouseY = 0.5f;
    private TextView status;

    public static boolean isRunning() { return instance != null; }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        if (targetPackage != null && !targetPackage.equals(pkg)) {
            if (status != null) status.setText("Paused • " + pkg);
        } else if (status != null) {
            status.setText(profile != null && profile.hasMouseZone ? "MOUSE READY" : "MAPPER READY");
        }
    }

    @Override public void onInterrupt() {}

    public static void startOverlay(android.content.Context context, String packageName) {
        if (instance != null) instance.showOverlay(packageName);
    }

    private void showOverlay(String packageName) {
        targetPackage = packageName;
        profile = ProfileStore.loadProfile(this, packageName);
        if (profile.controls.isEmpty() && !profile.hasMouseZone) {
            profile = new MappingProfile();
        }
        createWindowsIfNeeded();
        renderTouchLayer();
    }

    private void createWindowsIfNeeded() {
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (touchLayer == null) createTouchLayer();
        if (panel == null) createPanel();
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 22
                ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void createPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setGravity(Gravity.CENTER_VERTICAL);
        panel.setPadding(dp(5), dp(3), dp(5), dp(3));
        panel.setBackground(round(0xE91A1F29, 18));

        status = text("WG MAPPER", 11, Color.WHITE);
        panel.addView(status, new LinearLayout.LayoutParams(dp(105), dp(42)));

        Button mouse = miniButton("MOUSE");
        mouse.setOnClickListener(v -> {
            mouseMode = !mouseMode;
            mouse.setText(mouseMode ? "MOUSE ON" : "MOUSE");
            renderTouchLayer();
        });
        panel.addView(mouse, new LinearLayout.LayoutParams(dp(78), dp(42)));

        Button hide = miniButton("HIDE TOUCH");
        hide.setOnClickListener(v -> {
            hideTouchButtons = !hideTouchButtons;
            hide.setText(hideTouchButtons ? "SHOW TOUCH" : "HIDE TOUCH");
            renderTouchLayer();
        });
        panel.addView(hide, new LinearLayout.LayoutParams(dp(112), dp(42)));

        Button edit = miniButton("EDIT");
        edit.setOnClickListener(v -> {
            editMode = !editMode;
            edit.setText(editMode ? "LOCK" : "EDIT");
            renderTouchLayer();
        });
        panel.addView(edit, new LinearLayout.LayoutParams(dp(72), dp(42)));

        Button editor = miniButton("MAP");
        editor.setOnClickListener(v -> openEditor());
        panel.addView(editor, new LinearLayout.LayoutParams(dp(64), dp(42)));

        Button close = miniButton("×");
        close.setOnClickListener(v -> hideOverlay());
        panel.addView(close, new LinearLayout.LayoutParams(dp(48), dp(42)));

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = dp(42);
        try { wm.addView(panel, lp); } catch (Throwable t) { panel = null; }
    }

    private void createTouchLayer() {
        touchLayer = new FrameLayout(this);
        touchLayer.setBackgroundColor(Color.TRANSPARENT);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        try { wm.addView(touchLayer, lp); } catch (Throwable t) { touchLayer = null; }
    }

    private void renderTouchLayer() {
        if (touchLayer == null) return;
        touchLayer.removeAllViews();
        WindowManager.LayoutParams current = (WindowManager.LayoutParams) touchLayer.getLayoutParams();
        if (current != null) {
            if (editMode) current.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            else current.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            try { wm.updateViewLayout(touchLayer, current); } catch (Throwable ignored) {}
        }
        if (hideTouchButtons || profile == null) return;

        if (profile.hasMouseZone) {
            TextView zone = text("MOUSE\nZONE", 10, 0xFFBFE6FF);
            zone.setGravity(Gravity.CENTER);
            zone.setBackground(roundStroke(0x3327A7FF, 0xFF66C8FF, 2, 16));
            FrameLayout.LayoutParams zp = new FrameLayout.LayoutParams(
                    Math.max(dp(160), (int)(profile.mouseZone.width() * getResources().getDisplayMetrics().widthPixels)),
                    Math.max(dp(110), (int)(profile.mouseZone.height() * getResources().getDisplayMetrics().heightPixels)));
            zp.leftMargin = (int)(profile.mouseZone.left * getResources().getDisplayMetrics().widthPixels);
            zp.topMargin = (int)(profile.mouseZone.top * getResources().getDisplayMetrics().heightPixels);
            touchLayer.addView(zone, zp);
        }

        for (MappingProfile.Control c : profile.controls.values()) {
            if (c.keyCode == KeyEvent.KEYCODE_UNKNOWN) continue;
            Button b = miniButton(c.label);
            b.setTextSize(11);
            b.setTextColor(Color.WHITE);
            b.setBackground(roundStroke(0xAA303846, 0xFFDDE3EC, 2, 100));
            int size = Math.max(dp(48), (int)(c.size * getResources().getDisplayMetrics().widthPixels));
            FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(size, size);
            cp.leftMargin = (int)(c.x * getResources().getDisplayMetrics().widthPixels - size / 2f);
            cp.topMargin = (int)(c.y * getResources().getDisplayMetrics().heightPixels - size / 2f);
            touchLayer.addView(b, cp);
            if (editMode) {
                makeDraggable(b, cp, c);
            } else {
                // Buttons are visual mapping markers in normal mode. Game input is captured
                // by the accessibility key filter, so these markers do not need focus.
                b.setClickable(false);
                b.setFocusable(false);
            }
        }
    }

    private void makeDraggable(View v, FrameLayout.LayoutParams lp, MappingProfile.Control c) {
        v.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY, startX, startY;
            @Override public boolean onTouch(View view, android.view.MotionEvent e) {
                if (e.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    downX=e.getRawX(); downY=e.getRawY(); startX=lp.leftMargin; startY=lp.topMargin; return true;
                }
                if (e.getAction() == android.view.MotionEvent.ACTION_MOVE) {
                    lp.leftMargin=(int)Math.max(0,Math.min(getResources().getDisplayMetrics().widthPixels-view.getWidth(),startX+e.getRawX()-downX));
                    lp.topMargin=(int)Math.max(0,Math.min(getResources().getDisplayMetrics().heightPixels-view.getHeight(),startY+e.getRawY()-downY));
                    view.setLayoutParams(lp);
                    c.x=(lp.leftMargin+view.getWidth()/2f)/getResources().getDisplayMetrics().widthPixels;
                    c.y=(lp.topMargin+view.getHeight()/2f)/getResources().getDisplayMetrics().heightPixels;
                    return true;
                }
                if (e.getAction() == android.view.MotionEvent.ACTION_UP) {
                    ProfileStore.saveProfile(MapperAccessibilityService.this, targetPackage, profile);
                    return true;
                }
                return true;
            }
        });
    }

    @Override public boolean onKeyEvent(KeyEvent event) {
        if (profile == null || event == null) return false;
        InputDevice device = event.getDevice();
        if (device == null || !isController(device)) return false;
        if (event.getRepeatCount() > 0) return true;

        String current = getRootInActiveWindow() != null && getRootInActiveWindow().getPackageName() != null
                ? getRootInActiveWindow().getPackageName().toString() : targetPackage;
        if (targetPackage != null && current != null && !targetPackage.equals(current)) return false;

        int key = event.getKeyCode();
        MappingProfile.Control c = profile.controls.get(key);
        if (event.getAction() == KeyEvent.ACTION_DOWN && c != null) {
            if (mouseMode && profile.hasMouseZone && key == KeyEvent.KEYCODE_BUTTON_A) {
                dispatchTap(mouseX, mouseY);
            } else {
                dispatchTap(c.x, c.y);
            }
            return true;
        }

        if (mouseMode && profile.hasMouseZone && event.getAction() == KeyEvent.ACTION_DOWN) {
            if (key == KeyEvent.KEYCODE_DPAD_UP) { moveMouse(0, -0.04f); return true; }
            if (key == KeyEvent.KEYCODE_DPAD_DOWN) { moveMouse(0, 0.04f); return true; }
            if (key == KeyEvent.KEYCODE_DPAD_LEFT) { moveMouse(-0.04f, 0); return true; }
            if (key == KeyEvent.KEYCODE_DPAD_RIGHT) { moveMouse(0.04f, 0); return true; }
        }
        return false;
    }


    private void moveMouse(float dx, float dy) {
        RectF z = profile.mouseZone;
        mouseX = clamp(mouseX + dx * profile.mouseSensitivity, z.left, z.right);
        mouseY = clamp(mouseY + dy * profile.mouseSensitivity, z.top, z.bottom);
        dispatchTap(mouseX, mouseY);
        if (status != null) status.setText(String.format(java.util.Locale.US, "MOUSE %.0f%% %.0f%%", mouseX*100, mouseY*100));
    }

    private void dispatchTap(float nx, float ny) {
        if (Build.VERSION.SDK_INT < 24) return;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float x = clamp(nx, 0, 1) * dm.widthPixels;
        float y = clamp(ny, 0, 1) * dm.heightPixels;
        Path path = new Path(); path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 45);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    private void openEditor() {
        android.content.Intent i = new android.content.Intent(this, MappingEditorActivity.class);
        i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
        i.putExtra("package", targetPackage);
        i.putExtra("name", targetPackage == null ? "Game" : targetPackage);
        try { startActivity(i); } catch (Throwable ignored) {}
    }

    private boolean isController(InputDevice d) {
        int s = d.getSources();
        return (s & InputDevice.SOURCE_GAMEPAD) != 0 || (s & InputDevice.SOURCE_JOYSTICK) != 0;
    }

    private Button miniButton(String s) { Button b=new Button(this); b.setText(s); b.setTextSize(10); b.setAllCaps(false); return b; }
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private GradientDrawable round(int color,int r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));return g;}
    private GradientDrawable roundStroke(int fill,int stroke,int width,int r){GradientDrawable g=round(fill,r);g.setStroke(width,stroke);return g;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private float clamp(float v,float a,float b){return Math.max(a,Math.min(b,v));}

    private void hideOverlay() {
        if (touchLayer != null) { try { wm.removeView(touchLayer); } catch (Throwable ignored) {} }
        if (panel != null) { try { wm.removeView(panel); } catch (Throwable ignored) {} }
        touchLayer=null; panel=null;
    }

    @Override public void onDestroy() {
        hideOverlay(); instance=null; super.onDestroy();
    }
}
