# WeirdGamepad Launcher 1.2

Java + XML Android launcher with an Enhanced Mode mapper foundation.

## Included
- Installed-game launcher with per-game profiles.
- Java gamepad tester for digital buttons, D-pad, both sticks and analog L2/R2 trigger axes.
- Visual mapping editor: drag touch buttons to the game's touch-control positions.
- `+ ADD TOUCH` workflow: place an unbound touch point, then press the physical controller button to bind it.
- L1/L2/R1/R2, A/B/X/Y, L3/R3, START and D-pad mappings.
- Dedicated `MOUSE ZONE` that can be positioned over a game's area.
- `MOUSE` toggle in the floating panel; A clicks the mouse cursor and D-pad movement provides a digital fallback.
- Dedicated `HIDE TOUCH` / `SHOW TOUCH` toggle for hiding the mapper's visual touch buttons without deleting mappings.
- Floating accessibility overlay with EDIT/LOCK and MAP controls.
- Fade transition when opening/launching screens.
- Shizuku status/permission support retained for Enhanced Mode.
- Android API 36 / AGP 8.9.1 build configuration.

## Important Android limitation
Android's public AccessibilityService API exposes filtered key events but does not provide a public global callback for another app's joystick motion axes. Therefore the current floating mapper reliably supports digital controller keys and provides a D-pad mouse fallback. Full global analog-stick-to-mouse and sustained analog joystick injection requires a privileged input bridge (for example a supported Shizuku/root implementation) and is intentionally not faked by this version.

## Build
The GitHub Actions workflow uses Java 17, Gradle 8.11.1, and installs only platform-tools, Android API 36 and Build Tools 36.0.0.
