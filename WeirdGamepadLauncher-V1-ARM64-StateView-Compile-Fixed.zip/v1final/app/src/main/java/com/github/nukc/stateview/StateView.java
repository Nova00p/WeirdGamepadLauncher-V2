package com.github.nukc.stateview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

/**
 * Small local compatibility implementation for the StateView API used by the
 * original NewBlackbox sample. It intentionally has no external dependency.
 * The host layouts already contain the actual content views, so these methods
 * are safe no-op state markers for this V1 build.
 */
public class StateView extends FrameLayout {

    public StateView(Context context) {
        super(context);
    }

    public StateView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public StateView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void showLoading() {
        setVisibility(View.VISIBLE);
    }

    public void showEmpty() {
        setVisibility(View.VISIBLE);
    }

    public void showContent() {
        setVisibility(View.VISIBLE);
    }
}
