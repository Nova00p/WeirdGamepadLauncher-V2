package com.nova00p.weirdgamepadlauncher;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Map;

public final class ProfileStore {
    private static final String PREF = "mapping_profiles";

    private ProfileStore() {}

    public static Map<Integer, float[]> load(Context context, String packageName) {
        SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        Map<Integer, float[]> result = new HashMap<>();
        String raw = p.getString(packageName, "");
        if (raw == null || raw.isEmpty()) return result;

        for (String item : raw.split(";")) {
            String[] parts = item.split(",");
            if (parts.length != 3) continue;
            try {
                int key = Integer.parseInt(parts[0]);
                float x = Float.parseFloat(parts[1]);
                float y = Float.parseFloat(parts[2]);
                result.put(key, new float[]{x, y});
            } catch (NumberFormatException ignored) {}
        }
        return result;
    }

    public static void save(Context context, String packageName, Map<Integer, float[]> map) {
        StringBuilder out = new StringBuilder();
        for (Map.Entry<Integer, float[]> e : map.entrySet()) {
            if (out.length() > 0) out.append(";");
            out.append(e.getKey()).append(",")
               .append(e.getValue()[0]).append(",")
               .append(e.getValue()[1]);
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putString(packageName, out.toString()).apply();
    }
}
