package com.nova00p.weirdgamepadlauncher;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.*;
import android.widget.*;
import android.content.Context;
import android.view.accessibility.AccessibilityEvent;
import android.view.KeyEvent;

import java.util.HashMap;
import java.util.Map;

public class MapperAccessibilityService extends AccessibilityService {
    private static MapperAccessibilityService instance;
    private WindowManager wm;
    private View overlay;
    private String activePackage;
    private final Map<Integer, float[]> mapping = new HashMap<>();

    public static boolean isRunning() { return instance != null; }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event != null && event.getPackageName() != null) {
            activePackage = event.getPackageName().toString();
        }
    }

    @Override public void onInterrupt() {}

    public static void startOverlay(Context context, String packageName) {
        if (instance != null) instance.showOverlay(packageName);
    }

    private void showOverlay(String packageName) {
        activePackage = packageName;
        if (overlay != null) return;

        mapping.clear();
        mapping.put(KeyEvent.KEYCODE_BUTTON_A, new float[]{0.50f, 0.86f});
        mapping.put(KeyEvent.KEYCODE_BUTTON_B, new float[]{0.67f, 0.72f});
        mapping.put(KeyEvent.KEYCODE_BUTTON_X, new float[]{0.33f, 0.72f});
        mapping.put(KeyEvent.KEYCODE_BUTTON_Y, new float[]{0.50f, 0.62f});

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setPadding(8,8,8,8);
        panel.setBackgroundColor(0xDD151A23);

        TextView title = new TextView(this);
        title.setText(" MAPPER  •  " + packageName);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(12);
        panel.addView(title, new LinearLayout.LayoutParams(0, 52, 1));

        Button close = new Button(this);
        close.setText("×");
        close.setOnClickListener(v -> hideOverlay());
        panel.addView(close, new LinearLayout.LayoutParams(60, 52));

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = 80;
        overlay = panel;
        wm.addView(overlay, lp);
    }

    private void hideOverlay() {
        if (overlay != null && wm != null) {
            try { wm.removeView(overlay); } catch (Throwable ignored) {}
        }
        overlay = null;
    }

    @Override public boolean onKeyEvent(android.view.KeyEvent event) {
        if (event.getAction() != android.view.KeyEvent.ACTION_DOWN) return false;
        float[] point = mapping.get(event.getKeyCode());
        if (point == null) return false;
        dispatchTap(point[0], point[1]);
        return true;
    }

    private void dispatchTap(float nx, float ny) {
        if (Build.VERSION.SDK_INT < 24) return;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float x = nx * dm.widthPixels;
        float y = ny * dm.heightPixels;

        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 40);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    @Override public void onDestroy() {
        hideOverlay();
        instance = null;
        super.onDestroy();
    }
}
