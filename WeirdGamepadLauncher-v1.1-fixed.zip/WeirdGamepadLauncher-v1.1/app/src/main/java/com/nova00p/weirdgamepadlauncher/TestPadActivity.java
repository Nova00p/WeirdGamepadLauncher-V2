package com.nova00p.weirdgamepadlauncher;

import android.os.Bundle;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class TestPadActivity extends AppCompatActivity {
    private TextView deviceText, buttonText, stickText;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testpad);
        deviceText = findViewById(R.id.deviceText);
        buttonText = findViewById(R.id.buttonText);
        stickText = findViewById(R.id.stickText);
        findViewById(R.id.back).setOnClickListener(v -> finish());
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        InputDevice d = event.getDevice();
        if (d != null && isController(d)) {
            deviceText.setText("Connected: " + d.getName() + "\nID: " + d.getId());
            buttonText.setText("Key: " + KeyEvent.keyCodeToString(event.getKeyCode()) +
                    "\nAction: " + (event.getAction() == KeyEvent.ACTION_DOWN ? "DOWN" : "UP"));
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public boolean dispatchGenericMotionEvent(MotionEvent event) {
        InputDevice d = event.getDevice();
        if (d != null && isController(d) && (event.getSource() & InputDevice.SOURCE_JOYSTICK) != 0) {
            float x = event.getAxisValue(MotionEvent.AXIS_X);
            float y = event.getAxisValue(MotionEvent.AXIS_Y);
            float rx = event.getAxisValue(MotionEvent.AXIS_Z);
            float ry = event.getAxisValue(MotionEvent.AXIS_RZ);
            deviceText.setText("Connected: " + d.getName() + "\nID: " + d.getId());
            stickText.setText(String.format(Locale.US,
                    "Left: %.2f / %.2f\nRight: %.2f / %.2f", x,y,rx,ry));
            return true;
        }
        return super.dispatchGenericMotionEvent(event);
    }

    private boolean isController(InputDevice d) {
        int s = d.getSources();
        return (s & InputDevice.SOURCE_GAMEPAD) != 0 ||
               (s & InputDevice.SOURCE_JOYSTICK) != 0;
    }
}
