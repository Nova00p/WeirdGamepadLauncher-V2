package com.nova00p.weirdgamepadlauncher;

import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import java.util.*;

public class GameActivity extends AppCompatActivity {
    private String packageName;
    private String gameName;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        gameName = getIntent().getStringExtra("name");
        packageName = getIntent().getStringExtra("package");

        ((TextView)findViewById(R.id.gameName)).setText(gameName);
        ((TextView)findViewById(R.id.gamePackage)).setText(packageName);
        ((TextView)findViewById(R.id.scanStatus)).setText(
                "SCAN COMPLETE\n\nGenerated profile: Console Layout\n" +
                "Status: editable\n\nV1.1 uses a safe starter profile. " +
                "Online game-specific profiles are prepared for a later database service."
        );

        findViewById(R.id.playButton).setOnClickListener(v -> launchGame());
        findViewById(R.id.mapButton).setOnClickListener(v -> editMapping());
        findViewById(R.id.overlayButton).setOnClickListener(v -> startMapper());
        findViewById(R.id.backButton).setOnClickListener(v -> finish());
    }

    private void launchGame() {
        Intent i = getPackageManager().getLaunchIntentForPackage(packageName);
        if (i == null) {
            Toast.makeText(this, "Game launch activity not found.", Toast.LENGTH_SHORT).show();
            return;
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    private void editMapping() {
        final String[] labels = {
                "Cross / A → Tap: center-bottom",
                "Circle / B → Back / secondary",
                "Square / X → Tap: left action",
                "Triangle / Y → Tap: right action"
        };
        new AlertDialog.Builder(this)
                .setTitle("Console Mapping • " + gameName)
                .setItems(labels, (d, which) ->
                        Toast.makeText(this, "V1.1 editor: profile item selected. Full draggable editor is next.", Toast.LENGTH_SHORT).show())
                .setPositiveButton("DONE", null)
                .show();
    }

    private void startMapper() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
            return;
        }
        if (!MapperAccessibilityService.isRunning()) {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            Toast.makeText(this, "Enable WeirdGamepad Launcher accessibility service.", Toast.LENGTH_LONG).show();
            return;
        }
        MapperAccessibilityService.startOverlay(this, packageName);
        Toast.makeText(this, "Floating mapper started.", Toast.LENGTH_SHORT).show();
    }
}
