# WeirdGamepad Launcher v1.1

PS5-inspired Android game launcher foundation with:
- installed launcher-app/game discovery
- search
- real game launching
- gamepad button/stick tester
- Enhanced Mode status using Shizuku
- overlay permission flow
- AccessibilityService-based floating mapper foundation
- per-game mapping storage foundation
- GitHub Actions debug APK build

## Important v1.1 scope

This is the first functional foundation. The automatic online game-analysis/database and fully draggable mapping editor are intentionally staged for the next version. The starter mapper demonstrates the Android input path without claiming every game's controls can be inferred automatically.

## Build

GitHub Actions uses JDK 17 and builds:
`app/build/outputs/apk/debug/app-debug.apk`

Shizuku API dependency is 12.2.0. The Shizuku app/server is maintained separately; the app must have Shizuku installed and running for Enhanced Mode.
