package top.niunaijun.blackboxa.util;

interface IShizukuFileService {
    String[] getApkPaths(String packageName);
    void copyFile(String sourcePath, String targetPath);
}
