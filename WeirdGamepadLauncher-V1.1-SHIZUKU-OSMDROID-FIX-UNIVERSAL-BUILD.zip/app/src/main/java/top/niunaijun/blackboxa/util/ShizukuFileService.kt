package top.niunaijun.blackboxa.util

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Runs inside a Shizuku UserService (shell/root identity).
 * Performs privileged APK path lookup and copies APK files into the app cache.
 */
class ShizukuFileService : IShizukuFileService.Stub() {
    override fun getApkPaths(packageName: String): Array<String> {
        require(packageName.matches(Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+$")))
        val process = ProcessBuilder("pm", "path", packageName)
            .redirectErrorStream(false)
            .start()
        val output = process.inputStream.bufferedReader().use { it.readText() }
        val error = process.errorStream.bufferedReader().use { it.readText() }
        val code = process.waitFor()
        if (code != 0) throw IllegalStateException("pm path failed ($code): ${error.trim()}")
        return output.lineSequence()
            .map { it.trim() }
            .filter { it.startsWith("package:/") }
            .map { it.removePrefix("package:") }
            .distinct()
            .toList()
            .toTypedArray()
    }

    override fun copyFile(sourcePath: String, targetPath: String) {
        require(sourcePath.startsWith("/data/app/") ||
                sourcePath.startsWith("/product/app/") ||
                sourcePath.startsWith("/system/app/") ||
                sourcePath.startsWith("/system_ext/app/")) {
            "Unexpected APK path"
        }
        val source = File(sourcePath)
        val target = File(targetPath)
        require(source.isFile) { "APK source does not exist: $sourcePath" }
        target.parentFile?.mkdirs()
        FileInputStream(source).use { input ->
            FileOutputStream(target, false).use { output ->
                input.copyTo(output, DEFAULT_BUFFER_SIZE)
                output.fd.sync()
            }
        }
        require(target.isFile && target.length() > 0L) { "APK copy failed: $targetPath" }
    }
}
